import { useState, useEffect } from "react";
import { cn } from "@/lib/utils";

interface UserAvatarProps {
  name?: string;
  src?: string | null;
  size?: number;
  className?: string;
  ringClassName?: string;
}

/**
 * A resilient avatar component.
 *
 * Previously the app rendered a raw `<img>` and only showed a fallback
 * when `profileImageUrl` was falsy. If the URL existed but failed to load
 * (404, hot-link blocked, CORS, network error) the browser's broken
 * image icon was shown instead — this is the "main profile picture not
 * displaying" bug.
 *
 * This component:
 *   - swaps to a clean initials fallback when the image errors at runtime
 *   - sends no referrer so hot-link protection on third-party CDNs
 *     (e.g. Unsplash) doesn't block the request
 *   - generates a stable gradient per-user for the fallback so it doesn't
 *     look like an error state
 */
export function UserAvatar({
  name,
  src,
  size = 40,
  className,
  ringClassName,
}: UserAvatarProps) {
  const [failed, setFailed] = useState(false);

  // Reset error state when the src changes (so navigating between users works)
  useEffect(() => {
    setFailed(false);
  }, [src]);

  const initial = (name ?? "?").trim().charAt(0).toUpperCase() || "?";
  const gradient = getGradientForName(name ?? "");
  const showImage = !!src && !failed;

  return (
    <div
      className={cn(
        "relative shrink-0 rounded-full overflow-hidden",
        ringClassName,
        className,
      )}
      style={{ width: size, height: size }}
    >
      {showImage ? (
        <img
          src={src}
          alt={name ?? "User"}
          loading="lazy"
          referrerPolicy="no-referrer"
          onError={() => setFailed(true)}
          className="w-full h-full object-cover"
        />
      ) : (
        <div
          className="w-full h-full flex items-center justify-center text-white font-semibold select-none"
          style={{
            background: gradient,
            fontSize: Math.max(12, Math.round(size * 0.42)),
            letterSpacing: "-0.02em",
          }}
        >
          {initial}
        </div>
      )}
    </div>
  );
}

/** Deterministic, calm gradient picked from a small palette. */
function getGradientForName(name: string): string {
  const palettes = [
    "linear-gradient(135deg, #2f3a3a 0%, #1a2424 100%)", // slate forest
    "linear-gradient(135deg, #3b4a3f 0%, #1f2a23 100%)", // muted moss
    "linear-gradient(135deg, #4a4337 0%, #2a241c 100%)", // warm bark
    "linear-gradient(135deg, #3a3f4a 0%, #1f242e 100%)", // dusk blue
    "linear-gradient(135deg, #4a3a40 0%, #2a1f23 100%)", // dusty rose
  ];
  let hash = 0;
  for (let i = 0; i < name.length; i++) {
    hash = (hash * 31 + name.charCodeAt(i)) | 0;
  }
  return palettes[Math.abs(hash) % palettes.length];
}
