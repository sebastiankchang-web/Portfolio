import { Link, useLocation } from "wouter";
import { Home, Compass, Route, User } from "lucide-react";

const navItems = [
  { path: "/", icon: Home, label: "Home" },
  { path: "/social", icon: Compass, label: "Discover" },
  { path: "/trips", icon: Route, label: "Trips" },
  { path: "/profile", icon: User, label: "Profile" },
];

export function BottomNav() {
  const [location] = useLocation();

  return (
    <nav
      className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-sm z-50 safe-area-bottom
                 border-t border-[color:var(--app-line)]
                 bg-white/85 backdrop-blur-xl"
    >
      <div className="flex items-center justify-around px-2 pt-2 pb-2 pb-safe">
        {navItems.map(({ path, icon: Icon, label }) => {
          const active = location === path;
          return (
            <Link key={path} to={path}>
              <button
                aria-label={label}
                className={`group relative flex flex-col items-center justify-center
                            min-w-[64px] py-1.5 px-3 rounded-full
                            transition-all duration-200
                            ${active
                              ? "text-[color:var(--app-ink)]"
                              : "text-gray-400 hover:text-gray-600"}`}
              >
                <span
                  className={`flex items-center justify-center w-9 h-9 rounded-full transition-all
                              ${active ? "bg-[color:var(--app-sage-soft)]" : "bg-transparent"}`}
                >
                  <Icon
                    className="w-[18px] h-[18px]"
                    strokeWidth={active ? 2.25 : 1.75}
                  />
                </span>
                <span
                  className={`text-[10.5px] mt-0.5 tracking-wide transition-all
                              ${active ? "font-semibold" : "font-medium"}`}
                >
                  {label}
                </span>
              </button>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
