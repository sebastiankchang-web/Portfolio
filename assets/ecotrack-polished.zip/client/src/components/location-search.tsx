import { useState, useRef, useEffect } from 'react';
import { Search, MapPin, X } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';

const MAPBOX_TOKEN = import.meta.env.VITE_MAPBOX_TOKEN || 'pk.eyJ1Ijoic2ViYXN0aWFua2NoYW5nIiwiYSI6ImNtY2JqN3VwdTBhajcyaXB4Ymg4d3ZpMTEifQ.fNTiXoIsvQnmw4f2HvrqOw';

interface LocationResult {
  id: string;
  place_name: string;
  center: [number, number];
  context?: Array<{ id: string; text: string }>;
}

interface LocationSearchProps {
  onLocationSelect: (location: LocationResult) => void;
  placeholder?: string;
  value?: string;
  onInputChange?: (value: string) => void;
}

export function LocationSearch({ 
  onLocationSelect, 
  placeholder = "Search for a location...",
  value = "",
  onInputChange
}: LocationSearchProps) {
  const [query, setQuery] = useState(value);
  const [results, setResults] = useState<LocationResult[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);
  const timeoutRef = useRef<NodeJS.Timeout>();

  useEffect(() => {
    setQuery(value);
  }, [value]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setShowResults(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const searchLocations = async (searchQuery: string) => {
    if (!searchQuery.trim() || searchQuery.length < 3) {
      setResults([]);
      setShowResults(false);
      return;
    }

    setIsLoading(true);
    
    try {
      const response = await fetch(
        `https://api.mapbox.com/geocoding/v5/mapbox.places/${encodeURIComponent(searchQuery)}.json?` +
        `access_token=${MAPBOX_TOKEN}&` +
        `country=US,CA,GB,AU,DE,FR,IT,ES,NL,SE,NO,DK&` +
        `types=place,postcode,locality,neighborhood,address&` +
        `limit=5`
      );
      
      if (!response.ok) throw new Error('Search failed');
      
      const data = await response.json();
      setResults(data.features || []);
      setShowResults(true);
    } catch (error) {
      console.error('Location search error:', error);
      setResults([]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value;
    setQuery(newValue);
    onInputChange?.(newValue);

    // Clear previous timeout
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }

    // Debounce search
    timeoutRef.current = setTimeout(() => {
      searchLocations(newValue);
    }, 300);
  };

  const handleLocationSelect = (location: LocationResult) => {
    setQuery(location.place_name);
    setShowResults(false);
    onLocationSelect(location);
    onInputChange?.(location.place_name);
  };

  const clearSearch = () => {
    setQuery('');
    setResults([]);
    setShowResults(false);
    onInputChange?.('');
  };

  const formatLocationDescription = (location: LocationResult) => {
    if (!location.context) return '';
    
    const context = location.context
      .filter(c => c.id.includes('place') || c.id.includes('region') || c.id.includes('country'))
      .map(c => c.text)
      .join(', ');
    
    return context;
  };

  if (!MAPBOX_TOKEN || MAPBOX_TOKEN.startsWith('pk.your_token_here')) {
    return (
      <div className="relative">
        <Input
          type="text"
          placeholder="Location search requires Mapbox token"
          disabled
          className="pl-10 pr-4 py-3 rounded-2xl"
        />
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
      </div>
    );
  }

  return (
    <div ref={searchRef} className="relative">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
        <Input
          type="text"
          placeholder={placeholder}
          value={query}
          onChange={handleInputChange}
          className="pl-10 pr-10 py-3 rounded-2xl border-gray-200 focus:border-gray-500 focus:ring-gray-500"
          onFocus={() => query.length >= 3 && setShowResults(true)}
        />
        {query && (
          <button
            onClick={clearSearch}
            className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
          >
            <X className="w-5 h-5" />
          </button>
        )}
      </div>

      {showResults && (
        <Card className="absolute top-full left-0 right-0 mt-2 z-50 max-h-80 overflow-y-auto shadow-lg">
          <CardContent className="p-0">
            {isLoading ? (
              <div className="p-4 text-center">
                <div className="w-5 h-5 border-2 border-gray-500 border-t-transparent rounded-full animate-spin mx-auto mb-2"></div>
                <p className="text-sm text-gray-500">Searching locations...</p>
              </div>
            ) : results.length > 0 ? (
              <div className="divide-y divide-gray-100">
                {results.map((result) => (
                  <button
                    key={result.id}
                    onClick={() => handleLocationSelect(result)}
                    className="w-full p-4 text-left hover:bg-gray-50 transition-colors"
                  >
                    <div className="flex items-start space-x-3">
                      <MapPin className="w-5 h-5 text-gray-500 mt-0.5 flex-shrink-0" />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-gray-900 truncate">
                          {result.place_name.split(',')[0]}
                        </p>
                        <p className="text-xs text-gray-500 truncate">
                          {formatLocationDescription(result) || result.place_name}
                        </p>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            ) : query.length >= 3 ? (
              <div className="p-4 text-center text-gray-500">
                <MapPin className="w-8 h-8 mx-auto mb-2 text-gray-300" />
                <p className="text-sm">No locations found</p>
                <p className="text-xs">Try searching with a different term</p>
              </div>
            ) : null}
          </CardContent>
        </Card>
      )}
    </div>
  );
}