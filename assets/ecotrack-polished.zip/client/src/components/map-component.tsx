import { useEffect, useRef, useState } from 'react';
import mapboxgl from 'mapbox-gl';

// You'll need to get a Mapbox token from the user
const MAPBOX_TOKEN = import.meta.env.VITE_MAPBOX_TOKEN || 'pk.eyJ1Ijoic2ViYXN0aWFua2NoYW5nIiwiYSI6ImNtY2JqN3VwdTBhajcyaXB4Ymg4d3ZpMTEifQ.fNTiXoIsvQnmw4f2HvrqOw';

interface RouteOption {
  geometry: any;
  duration: number;
  distance: number;
  profile: string;
}

interface MapComponentProps {
  startCoords?: [number, number];
  endCoords?: [number, number];
  onLocationSelect?: (coords: [number, number], address: string) => void;
  height?: string;
  showRoute?: boolean;
  transportMode?: string;
  onRouteSelect?: (route: RouteOption) => void;
}

export function MapComponent({ 
  startCoords, 
  endCoords, 
  onLocationSelect, 
  height = '300px',
  showRoute = false,
  transportMode = 'walking',
  onRouteSelect
}: MapComponentProps) {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<mapboxgl.Map | null>(null);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    if (!mapContainer.current || map.current) return;

    mapboxgl.accessToken = MAPBOX_TOKEN;

    map.current = new mapboxgl.Map({
      container: mapContainer.current,
      style: 'mapbox://styles/mapbox/light-v11',
      center: startCoords || [-74.006, 40.7128], // Default to NYC
      zoom: 12,
      attributionControl: false,
    });

    map.current.on('load', () => {
      setIsLoaded(true);
    });

    // Add click handler for location selection
    if (onLocationSelect) {
      map.current.on('click', async (e) => {
        const { lng, lat } = e.lngLat;
        
        // Reverse geocoding to get address
        try {
          const response = await fetch(
            `https://api.mapbox.com/geocoding/v5/mapbox.places/${lng},${lat}.json?access_token=${MAPBOX_TOKEN}`
          );
          const data = await response.json();
          const address = data.features[0]?.place_name || `${lat.toFixed(4)}, ${lng.toFixed(4)}`;
          
          onLocationSelect([lng, lat], address);
        } catch (error) {
          console.error('Error getting address:', error);
          onLocationSelect([lng, lat], `${lat.toFixed(4)}, ${lng.toFixed(4)}`);
        }
      });
    }

    return () => {
      if (map.current) {
        map.current.remove();
        map.current = null;
      }
    };
  }, []);

  useEffect(() => {
    if (!map.current || !isLoaded) return;

    // Clear existing markers and routes
    const markers = document.querySelectorAll('.mapboxgl-marker');
    markers.forEach(marker => marker.remove());

    // Add start marker
    if (startCoords) {
      new mapboxgl.Marker({ color: '#374151' })
        .setLngLat(startCoords)
        .addTo(map.current);
    }

    // Add end marker
    if (endCoords) {
      new mapboxgl.Marker({ color: '#6b7280' })
        .setLngLat(endCoords)
        .addTo(map.current);
    }

    // Show route if both coordinates are provided
    if (showRoute && startCoords && endCoords) {
      drawRoutes(startCoords, endCoords, transportMode);
    }

    // Fit bounds to show both points
    if (startCoords && endCoords) {
      const bounds = new mapboxgl.LngLatBounds()
        .extend(startCoords)
        .extend(endCoords);
      
      map.current.fitBounds(bounds, {
        padding: 50,
        maxZoom: 15
      });
    } else if (startCoords) {
      map.current.flyTo({
        center: startCoords,
        zoom: 14
      });
    }
  }, [startCoords, endCoords, showRoute, transportMode, isLoaded]);

  const drawRoutes = async (start: [number, number], end: [number, number], mode: string) => {
    if (!map.current) return;

    // Clear existing routes
    ['route-primary', 'route-alt1', 'route-alt2'].forEach(id => {
      if (map.current?.getSource(id)) {
        map.current.removeLayer(id);
        map.current.removeSource(id);
      }
    });

    try {
      // Get routing profile based on transport mode
      const getRoutingProfile = (transportMode: string) => {
        const profiles = {
          walking: 'walking',
          cycling: 'cycling',
          publicTransport: 'driving-traffic',
          carpool: 'driving-traffic',
          electricVehicle: 'driving-traffic',
          airplane: 'driving'
        };
        return profiles[transportMode as keyof typeof profiles] || 'walking';
      };

      const profile = getRoutingProfile(mode);
      
      // For airplane, draw straight line
      if (mode === 'airplane') {
        const straightLine = {
          type: 'Feature',
          properties: { type: 'primary' },
          geometry: {
            type: 'LineString',
            coordinates: [start, end]
          }
        };

        map.current.addSource('route-primary', {
          type: 'geojson',
          data: straightLine
        });

        map.current.addLayer({
          id: 'route-primary',
          type: 'line',
          source: 'route-primary',
          layout: {
            'line-join': 'round',
            'line-cap': 'round'
          },
          paint: {
            'line-color': '#374151',
            'line-width': 4,
            'line-dasharray': [2, 2]
          }
        });

        // Calculate straight-line distance for airplane
        const distance = calculateStraightLineDistance(start, end);
        if (onRouteSelect) {
          onRouteSelect({
            geometry: straightLine.geometry,
            duration: distance * 60, // Approximate flight time in minutes
            distance: distance,
            profile: 'airplane'
          });
        }
        return;
      }

      // Get multiple route alternatives
      const response = await fetch(
        `https://api.mapbox.com/directions/v5/mapbox/${profile}/${start[0]},${start[1]};${end[0]},${end[1]}?` +
        `geometries=geojson&alternatives=true&steps=true&access_token=${MAPBOX_TOKEN}`
      );
      
      const data = await response.json();
      
      if (data.routes && data.routes.length > 0) {
        const colors = ['#374151', '#6b7280', '#9ca3af'];
        const widths = [4, 3, 2];
        
        data.routes.slice(0, 3).forEach((route: any, index: number) => {
          const routeId = index === 0 ? 'route-primary' : `route-alt${index}`;
          
          map.current?.addSource(routeId, {
            type: 'geojson',
            data: {
              type: 'Feature',
              properties: { 
                type: index === 0 ? 'primary' : 'alternative',
                duration: route.duration,
                distance: route.distance 
              },
              geometry: route.geometry
            }
          });

          map.current?.addLayer({
            id: routeId,
            type: 'line',
            source: routeId,
            layout: {
              'line-join': 'round',
              'line-cap': 'round'
            },
            paint: {
              'line-color': colors[index],
              'line-width': widths[index],
              'line-opacity': index === 0 ? 1 : 0.7
            }
          });

          // Add click handler for route selection
          map.current?.on('click', routeId, () => {
            if (onRouteSelect) {
              onRouteSelect({
                geometry: route.geometry,
                duration: route.duration,
                distance: route.distance / 1000,
                profile: profile
              });
            }
          });
        });

        // Automatically select the primary route
        if (onRouteSelect && data.routes[0]) {
          onRouteSelect({
            geometry: data.routes[0].geometry,
            duration: data.routes[0].duration,
            distance: data.routes[0].distance / 1000,
            profile: profile
          });
        }
      }
    } catch (error) {
      console.error('Error drawing routes:', error);
    }
  };

  const calculateStraightLineDistance = (start: [number, number], end: [number, number]) => {
    const R = 6371;
    const dLat = (end[1] - start[1]) * Math.PI / 180;
    const dLon = (end[0] - start[0]) * Math.PI / 180;
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(start[1] * Math.PI / 180) * Math.cos(end[1] * Math.PI / 180) * 
      Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  };

  if (!MAPBOX_TOKEN || MAPBOX_TOKEN.startsWith('pk.your_token_here')) {
    return (
      <div 
        className="bg-gray-100 rounded-xl flex items-center justify-center text-gray-500"
        style={{ height }}
      >
        <div className="text-center">
          <p className="text-sm">Map requires Mapbox token</p>
          <p className="text-xs">Set VITE_MAPBOX_TOKEN environment variable</p>
        </div>
      </div>
    );
  }

  return (
    <div 
      ref={mapContainer}
      className="w-full rounded-xl overflow-hidden"
      style={{ height }}
    />
  );
}