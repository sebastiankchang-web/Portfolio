import { useQuery } from "@tanstack/react-query";

interface CurrentUser {
  id: number;
  username: string;
  displayName: string;
  profileImageUrl?: string;
  bio?: string;
  isPublic: boolean;
}

export function useCurrentUser() {
  return useQuery<CurrentUser>({
    queryKey: ["/api/current-user"],
    staleTime: Infinity,
  });
}
