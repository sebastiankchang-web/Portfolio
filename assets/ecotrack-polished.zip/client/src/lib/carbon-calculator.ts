export const TRANSPORT_MODES = {
  walking: {
    name: 'Walking',
    icon: '🚶',
    carbonPerKm: 0, // kg CO2 per km
    color: 'bg-gray-100 text-gray-600',
    routingProfile: 'walking'
  },
  cycling: {
    name: 'Cycling',
    icon: '🚴',
    carbonPerKm: 0,
    color: 'bg-gray-100 text-gray-600',
    routingProfile: 'cycling'
  },
  publicTransport: {
    name: 'Public Transport',
    icon: '🚌',
    carbonPerKm: 0.05,
    color: 'bg-gray-100 text-gray-600',
    routingProfile: 'driving-traffic'
  },
  electricVehicle: {
    name: 'Electric Vehicle',
    icon: '🔋',
    carbonPerKm: 0.02,
    color: 'bg-gray-100 text-gray-600',
    routingProfile: 'driving-traffic'
  },
  carpool: {
    name: 'Carpool',
    icon: '🚗',
    carbonPerKm: 0.1,
    color: 'bg-gray-100 text-gray-600',
    routingProfile: 'driving-traffic'
  },
  airplane: {
    name: 'Airplane',
    icon: '✈️',
    carbonPerKm: 0.25,
    color: 'bg-gray-100 text-gray-600',
    routingProfile: 'driving'
  }
} as const;

export type TransportMode = keyof typeof TRANSPORT_MODES;

export function calculateCarbonSaved(transportMode: TransportMode, distance: number): number {
  const carEmission = distance * 0.21; // Standard car emission baseline
  const modeEmission = distance * TRANSPORT_MODES[transportMode].carbonPerKm;
  
  return Math.max(0, carEmission - modeEmission);
}

export function formatCarbonSaved(carbonSaved: number): string {
  if (carbonSaved < 0.1) {
    return `${Math.round(carbonSaved * 1000)}g`;
  }
  return `${carbonSaved.toFixed(1)}kg`;
}

export function getCarbonSavingsMessage(carbonSaved: number): string {
  if (carbonSaved >= 5) {
    return "Amazing! You're making a huge impact! 🌟";
  } else if (carbonSaved >= 2) {
    return "Great job! Every bit counts! 🌱";
  } else if (carbonSaved >= 0.5) {
    return "Nice work! Keep it up! 👍";
  } else {
    return "Every sustainable choice matters! 💚";
  }
}
