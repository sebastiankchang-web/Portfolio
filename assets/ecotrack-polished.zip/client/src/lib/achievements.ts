import type { Achievement } from "@shared/schema";

export interface AchievementTemplate {
  type: string;
  title: string;
  description: string;
  icon: string;
  threshold: number;
  gradient: string;
}

export const ACHIEVEMENT_TEMPLATES: AchievementTemplate[] = [
  {
    type: 'cycling_champion',
    title: 'Cycle Champion',
    description: '50 bike trips',
    icon: '🚴',
    threshold: 50,
    gradient: 'from-gray-700 to-gray-600'
  },
  {
    type: 'eco_warrior',
    title: 'Eco Warrior',
    description: '100kg CO₂ saved',
    icon: '🌟',
    threshold: 100,
    gradient: 'from-gray-800 to-gray-700'
  },
  {
    type: 'transit_pro',
    title: 'Transit Pro',
    description: '30 public trips',
    icon: '🚌',
    threshold: 30,
    gradient: 'from-gray-600 to-gray-500'
  },
  {
    type: 'walking_hero',
    title: 'Walking Hero',
    description: '100km on foot',
    icon: '🚶',
    threshold: 100,
    gradient: 'from-gray-700 to-gray-500'
  },
  {
    type: 'green_commuter',
    title: 'Green Commuter',
    description: '7 day streak',
    icon: '🍃',
    threshold: 7,
    gradient: 'from-gray-800 to-gray-600'
  },
  {
    type: 'carbon_crusher',
    title: 'Carbon Crusher',
    description: '50kg CO₂ saved',
    icon: '💚',
    threshold: 50,
    gradient: 'from-gray-600 to-gray-700'
  }
];

export function checkForNewAchievements(
  userTrips: any[],
  totalCarbonSaved: number,
  currentStreak: number,
  existingAchievements: Achievement[]
): AchievementTemplate[] {
  const newAchievements: AchievementTemplate[] = [];
  const existingTypes = new Set(existingAchievements.map(a => a.achievementType));

  const tripCounts = userTrips.reduce((acc, trip) => {
    acc[trip.transportMode] = (acc[trip.transportMode] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const walkingDistance = userTrips
    .filter(trip => trip.transportMode === 'walking')
    .reduce((sum, trip) => sum + trip.distance, 0);

  for (const template of ACHIEVEMENT_TEMPLATES) {
    if (existingTypes.has(template.type)) continue;
    let unlocked = false;
    switch (template.type) {
      case 'cycling_champion':
        unlocked = (tripCounts.cycling || 0) >= template.threshold;
        break;
      case 'eco_warrior':
        unlocked = totalCarbonSaved >= template.threshold;
        break;
      case 'transit_pro':
        unlocked = (tripCounts.publicTransport || 0) >= template.threshold;
        break;
      case 'walking_hero':
        unlocked = walkingDistance >= template.threshold;
        break;
      case 'green_commuter':
        unlocked = currentStreak >= template.threshold;
        break;
      case 'carbon_crusher':
        unlocked = totalCarbonSaved >= template.threshold;
        break;
    }
    if (unlocked) newAchievements.push(template);
  }

  return newAchievements;
}

export function getAchievementGradient(achievementType: string): string {
  const template = ACHIEVEMENT_TEMPLATES.find(t => t.type === achievementType);
  return template?.gradient || 'from-gray-600 to-gray-700';
}
