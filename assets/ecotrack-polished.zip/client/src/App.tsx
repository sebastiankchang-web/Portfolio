import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { BottomNav } from "@/components/bottom-nav";
import Dashboard from "@/pages/dashboard";
import LogTrip from "@/pages/log-trip";
import Stats from "@/pages/stats";
import Trips from "@/pages/trips";
import Profile from "@/pages/profile";
import Social from "@/pages/social";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/log-trip" component={LogTrip} />
      <Route path="/stats" component={Stats} />
      <Route path="/trips" component={Trips} />
      <Route path="/profile" component={Profile} />
      <Route path="/social" component={Social} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="relative">
          <Router />
          <BottomNav />
        </div>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
