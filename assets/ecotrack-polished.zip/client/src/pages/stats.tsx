import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, TrendingUp, Calendar, Target, Sparkles } from "lucide-react";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ProgressRing } from "@/components/progress-ring";
import { useCurrentUser } from "@/hooks/use-current-user";

interface UserStats {
  totalCarbonSaved: number;
  totalTrips: number;
  currentStreak: number;
  longestStreak: number;
  monthlyGoal: number;
}

export default function Stats() {
  const { data: currentUser } = useCurrentUser();
  const userId = currentUser?.id;

  const { data: stats, isLoading } = useQuery<UserStats>({
    queryKey: [`/api/user/${userId}/stats`],
    enabled: !!userId,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-7 h-7 border-[2.5px] border-[color:var(--app-sage)] border-t-transparent rounded-full animate-spin mx-auto mb-3" />
          <p className="text-sm text-muted-foreground">Loading your stats…</p>
        </div>
      </div>
    );
  }

  if (!stats) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-sm text-muted-foreground">
          We couldn't load your stats.
        </p>
      </div>
    );
  }

  const monthlyProgress = Math.min(
    100,
    (stats.totalCarbonSaved / stats.monthlyGoal) * 100,
  );
  const weeklyProgress = Math.min(100, (stats.currentStreak / 7) * 100);

  return (
    <div className="min-h-screen bg-background pb-24 safe-area-bottom">
      <div className="max-w-sm mx-auto bg-background min-h-screen ios-scroll">
        <header className="bg-[color:var(--app-ink)] text-white px-5 pt-4 pb-6 rounded-b-[28px] shadow-ink ring-hairline safe-area-top">
          <div className="flex items-center gap-3">
            <Link to="/">
              <button
                aria-label="Back"
                className="w-10 h-10 rounded-full bg-white/10 hover:bg-white/15 flex items-center justify-center transition-colors"
              >
                <ArrowLeft className="w-5 h-5" strokeWidth={1.75} />
              </button>
            </Link>
            <div>
              <p className="text-[10px] uppercase tracking-[0.18em] text-white/60">
                Insights
              </p>
              <h1 className="text-[20px] font-semibold leading-tight">
                Your stats
              </h1>
            </div>
          </div>
        </header>

        <main className="px-5 py-6 space-y-5">
          <Card className="rounded-2xl border-[color:var(--app-line)] shadow-elev-1">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center text-[15px] font-semibold">
                <TrendingUp
                  className="w-4 h-4 mr-2 text-[color:var(--app-sage)]"
                  strokeWidth={1.75}
                />
                Total impact
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center">
                  <div className="font-display text-[32px] leading-none text-foreground tabular-nums">
                    {stats.totalCarbonSaved.toFixed(1)}
                  </div>
                  <div className="text-[11px] uppercase tracking-wider text-muted-foreground mt-2">
                    kg CO₂ saved
                  </div>
                </div>
                <div className="text-center">
                  <div className="font-display text-[32px] leading-none text-foreground tabular-nums">
                    {stats.totalTrips}
                  </div>
                  <div className="text-[11px] uppercase tracking-wider text-muted-foreground mt-2">
                    Eco trips
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="rounded-2xl border-[color:var(--app-line)] shadow-elev-1">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center text-[15px] font-semibold">
                <Target
                  className="w-4 h-4 mr-2 text-[color:var(--app-sage)]"
                  strokeWidth={1.75}
                />
                Progress
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex justify-around">
                <div className="text-center">
                  <ProgressRing progress={monthlyProgress} size={104}>
                    <div className="text-center">
                      <div className="font-display text-[22px] leading-none text-foreground tabular-nums">
                        {Math.round(monthlyProgress)}%
                      </div>
                    </div>
                  </ProgressRing>
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground mt-3">
                    Monthly goal
                  </div>
                  <div className="text-[13px] font-semibold text-foreground tabular-nums">
                    {stats.totalCarbonSaved.toFixed(1)} / {stats.monthlyGoal} kg
                  </div>
                </div>
                <div className="text-center">
                  <ProgressRing
                    progress={weeklyProgress}
                    color="var(--app-ink-soft)"
                    size={104}
                  >
                    <div className="text-center">
                      <div className="font-display text-[22px] leading-none text-foreground tabular-nums">
                        {Math.round(weeklyProgress)}%
                      </div>
                    </div>
                  </ProgressRing>
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground mt-3">
                    Weekly streak
                  </div>
                  <div className="text-[13px] font-semibold text-foreground tabular-nums">
                    {stats.currentStreak} / 7 days
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="rounded-2xl border-[color:var(--app-line)] shadow-elev-1">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center text-[15px] font-semibold">
                <Calendar
                  className="w-4 h-4 mr-2 text-[color:var(--app-sage)]"
                  strokeWidth={1.75}
                />
                Streaks
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-3">
                <StreakTile value={stats.currentStreak} label="Current" />
                <StreakTile value={stats.longestStreak} label="Longest" />
              </div>
            </CardContent>
          </Card>

          <Card className="rounded-2xl bg-[color:var(--app-sage-soft)] border-[color:var(--app-sage)]/15 shadow-elev-1">
            <CardContent className="p-6">
              <h3 className="text-[15px] font-semibold text-foreground mb-4 flex items-center">
                <Sparkles
                  className="w-4 h-4 mr-2 text-[color:var(--app-sage)]"
                  strokeWidth={1.75}
                />
                Environmental impact
              </h3>
              <div className="space-y-3">
                <ImpactRow
                  label="Trees planted, equivalent"
                  value={`${Math.round(stats.totalCarbonSaved * 0.045)} trees`}
                />
                <ImpactRow
                  label="Miles not driven"
                  value={`${Math.round(stats.totalCarbonSaved * 2.4)} mi`}
                />
                <ImpactRow
                  label="Plastic bottles saved"
                  value={`${Math.round(stats.totalCarbonSaved * 45)}`}
                />
              </div>
              <p className="text-[13px] text-foreground/70 text-center mt-5">
                Quiet choices, real difference.
              </p>
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
}

function StreakTile({ value, label }: { value: number; label: string }) {
  return (
    <div className="text-center p-4 rounded-xl bg-secondary/60 border border-[color:var(--app-line)]">
      <div className="font-display text-[26px] leading-none text-foreground tabular-nums">
        {value}
      </div>
      <div className="text-[11px] uppercase tracking-wider text-muted-foreground mt-1.5">
        {label}
      </div>
      <div className="text-[10px] text-muted-foreground/70 mt-0.5">days</div>
    </div>
  );
}

function ImpactRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between items-center">
      <span className="text-sm text-foreground/70">{label}</span>
      <span className="font-semibold text-foreground tabular-nums">{value}</span>
    </div>
  );
}
