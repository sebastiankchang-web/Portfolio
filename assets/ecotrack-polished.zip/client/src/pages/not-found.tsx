import { Link } from "wouter";
import { Leaf } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-background px-6">
      <div className="text-center max-w-sm">
        <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-[color:var(--app-sage-soft)] text-[color:var(--app-sage)] mb-5">
          <Leaf className="w-6 h-6" strokeWidth={1.75} />
        </div>
        <p className="font-display text-[44px] leading-none text-foreground tabular-nums">
          404
        </p>
        <h1 className="text-[17px] font-semibold text-foreground mt-3">
          We couldn't find that page
        </h1>
        <p className="text-sm text-muted-foreground mt-2">
          The link may have moved, or you may have mistyped the address.
        </p>
        <Link to="/">
          <button className="mt-6 px-5 py-2.5 rounded-full bg-[color:var(--app-ink)] hover:bg-[color:var(--app-ink-soft)] text-white text-sm font-medium">
            Back to home
          </button>
        </Link>
      </div>
    </div>
  );
}
