import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Plus,
  Leaf,
  Route,
  Target,
  Bike,
  Sparkles,
  Heart,
  ArrowUpRight,
} from "lucide-react";
import { Link } from "wouter";
import { ProgressRing } from "@/components/progress-ring";
import { UserAvatar } from "@/components/user-avatar";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { TRANSPORT_MODES, type TransportMode } from "@/lib/carbon-calculator";
import { getAchievementGradient } from "@/lib/achievements";
import { useCurrentUser } from "@/hooks/use-current-user";

interface DashboardData {
  user: {
    id: number;
    username: string;
    displayName: string;
    profileImageUrl?: string;
    bio?: string;
  };
  stats: {
    totalCarbonSaved: number;
    totalTrips: number;
    currentStreak: number;
    monthlyGoal: number;
    followersCount: number;
    followingCount: number;
  };
  todayCarbon: number;
  weeklyStats: {
    ecoTrips: number;
    carbonSaved: number;
    favoriteMode: string;
    goalProgress: number;
  };
  recentTrips: Array<{
    id: number;
    transportMode: string;
    startLocation: string;
    endLocation: string;
    distance: number;
    carbonSaved: number;
    date: string;
  }>;
  recentAchievements: Array<{
    id: number;
    achievementType: string;
    title: string;
    description: string;
    icon: string;
  }>;
  feedPosts: Array<{
    id: number;
    content: string;
    user: {
      id: number;
      displayName: string;
      username: string;
      profileImageUrl?: string;
    };
    trip?: {
      transportMode: string;
      distance: number;
      carbonSaved: number;
      startLocation: string;
      endLocation: string;
    };
    likeCount: number;
    isLiked: boolean;
    createdAt: string;
  }>;
}

function formatTimeAgo(date: string) {
  const now = new Date();
  const tripDate = new Date(date);
  const diffInHours = Math.floor(
    (now.getTime() - tripDate.getTime()) / (1000 * 60 * 60),
  );
  if (diffInHours < 1) return "Just now";
  if (diffInHours === 1) return "1h ago";
  if (diffInHours < 24) return `${diffInHours}h ago`;
  if (diffInHours < 48) return "Yesterday";
  return `${Math.floor(diffInHours / 24)}d ago`;
}

function PageLoader({ label = "Loading" }: { label?: string }) {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center">
      <div className="text-center">
        <div className="w-7 h-7 border-[2.5px] border-[color:var(--app-sage)] border-t-transparent rounded-full animate-spin mx-auto mb-3" />
        <p className="text-sm text-muted-foreground tracking-wide">{label}…</p>
      </div>
    </div>
  );
}

export default function Dashboard() {
  const queryClient = useQueryClient();
  const { data: currentUser, isLoading: isUserLoading } = useCurrentUser();
  const userId = currentUser?.id;

  const { data: dashboardData, isLoading: isDashboardLoading } =
    useQuery<DashboardData>({
      queryKey: [`/api/user/${userId}/dashboard`],
      enabled: !!userId,
      retry: 3,
      retryDelay: 1000,
    });

  const isLoading = isUserLoading || isDashboardLoading;
  if (isLoading) return <PageLoader label="Loading your dashboard" />;

  if (!dashboardData) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center px-6 text-center">
        <div>
          <p className="text-sm text-muted-foreground mb-3">
            We couldn't load your dashboard.
          </p>
          <Button
            onClick={() =>
              queryClient.invalidateQueries({
                queryKey: [`/api/user/${userId}/dashboard`],
              })
            }
            className="bg-[color:var(--app-ink)] hover:bg-[color:var(--app-ink-soft)] text-white rounded-full px-5"
          >
            Try again
          </Button>
        </div>
      </div>
    );
  }

  const monthlyProgress = Math.min(
    100,
    (dashboardData.stats.totalCarbonSaved / dashboardData.stats.monthlyGoal) * 100,
  );

  return (
    <div className="min-h-screen bg-background pb-24 safe-area-bottom">
      <div className="max-w-sm mx-auto bg-background min-h-screen ios-scroll">
        {/* Sticky header */}
        <header className="px-5 pt-5 pb-3 safe-area-top sticky top-0 z-20 bg-background/85 backdrop-blur-xl border-b border-[color:var(--app-line)]/70">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <UserAvatar
                src={dashboardData.user.profileImageUrl}
                name={dashboardData.user.displayName}
                size={44}
                ringClassName="ring-1 ring-[color:var(--app-line)]"
              />
              <div className="leading-tight">
                <p className="text-[11px] uppercase tracking-[0.14em] text-muted-foreground">
                  Welcome back
                </p>
                <h1 className="text-[17px] font-semibold text-foreground">
                  {dashboardData.user.displayName}
                </h1>
              </div>
            </div>
            <div className="flex items-center gap-4 text-right">
              <div>
                <div className="text-sm font-semibold tabular-nums">
                  {dashboardData.stats.followersCount}
                </div>
                <div className="text-[10px] uppercase tracking-wider text-muted-foreground">
                  Followers
                </div>
              </div>
              <div>
                <div className="text-sm font-semibold tabular-nums">
                  {dashboardData.stats.followingCount}
                </div>
                <div className="text-[10px] uppercase tracking-wider text-muted-foreground">
                  Following
                </div>
              </div>
            </div>
          </div>
        </header>

        {/* Hero impact card */}
        <section className="mx-5 mt-5">
          <div className="rounded-[28px] bg-[color:var(--app-ink)] text-white p-6 shadow-ink ring-hairline">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2 text-white/70">
                <Leaf className="w-4 h-4" strokeWidth={1.75} />
                <span className="text-xs uppercase tracking-[0.16em]">
                  Today's Impact
                </span>
              </div>
              <span className="text-[11px] text-white/60">
                vs your daily avg
              </span>
            </div>
            <div className="flex items-end justify-between">
              <div>
                <div className="font-display text-[44px] leading-none tabular-nums">
                  {dashboardData.todayCarbon.toFixed(1)}
                </div>
                <div className="text-xs mt-2 text-white/70 tracking-wide">
                  kg CO₂ avoided today
                </div>
              </div>
              <div className="flex items-center gap-1 text-emerald-300/90 text-sm font-semibold">
                <ArrowUpRight className="w-4 h-4" />
                <span>+47%</span>
              </div>
            </div>
          </div>
        </section>

        <main className="px-5 pt-6">
          {/* Quick actions */}
          <section className="grid grid-cols-2 gap-3 mb-7">
            <Link to="/log-trip">
              <Button className="w-full h-12 bg-[color:var(--app-ink)] hover:bg-[color:var(--app-ink-soft)] text-white rounded-2xl font-medium shadow-elev-1">
                <Plus className="w-4 h-4 mr-1.5" strokeWidth={2} />
                Log a trip
              </Button>
            </Link>
            <Link to="/social">
              <Button
                variant="outline"
                className="w-full h-12 bg-white border-[color:var(--app-line)] text-foreground rounded-2xl font-medium hover:bg-secondary"
              >
                <Sparkles className="w-4 h-4 mr-1.5" strokeWidth={2} />
                Discover
              </Button>
            </Link>
          </section>

          {/* Activity feed */}
          {dashboardData.feedPosts && dashboardData.feedPosts.length > 0 && (
            <section className="mb-8">
              <SectionHeader title="Activity" linkTo="/social" linkLabel="See more" />
              <div className="space-y-3">
                {dashboardData.feedPosts.slice(0, 3).map((post) => (
                  <Card
                    key={post.id}
                    className="rounded-2xl border-[color:var(--app-line)] shadow-elev-1"
                  >
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <UserAvatar
                          src={post.user.profileImageUrl}
                          name={post.user.displayName}
                          size={40}
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-1.5 mb-1.5">
                            <span className="font-semibold text-[14px] text-foreground truncate">
                              {post.user.displayName}
                            </span>
                            <span className="text-muted-foreground text-[13px] truncate">
                              @{post.user.username}
                            </span>
                            <span className="text-muted-foreground/70 text-xs">·</span>
                            <span className="text-muted-foreground text-xs">
                              {formatTimeAgo(post.createdAt)}
                            </span>
                          </div>
                          <p className="text-[14.5px] text-foreground/90 leading-relaxed mb-3">
                            {post.content}
                          </p>

                          {post.trip && (
                            <div className="bg-secondary/60 border border-[color:var(--app-line)] rounded-xl p-3 mb-3">
                              <div className="flex items-center gap-2 mb-1.5">
                                <span className="text-base">
                                  {TRANSPORT_MODES[
                                    post.trip.transportMode as TransportMode
                                  ]?.icon || "🚗"}
                                </span>
                                <span className="text-[13px] font-medium text-foreground truncate">
                                  {post.trip.startLocation} → {post.trip.endLocation}
                                </span>
                              </div>
                              <div className="flex items-center gap-3 text-xs text-muted-foreground tabular-nums">
                                <span>{post.trip.distance.toFixed(1)} km</span>
                                <span>·</span>
                                <span className="font-semibold text-[color:var(--app-sage)]">
                                  −{post.trip.carbonSaved.toFixed(1)} kg CO₂
                                </span>
                              </div>
                            </div>
                          )}

                          <button className="inline-flex items-center gap-1.5 text-muted-foreground hover:text-rose-500 transition-colors">
                            <Heart
                              className={`w-4 h-4 ${post.isLiked ? "fill-rose-500 text-rose-500" : ""}`}
                              strokeWidth={1.75}
                            />
                            <span className="text-xs tabular-nums">{post.likeCount}</span>
                          </button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </section>
          )}

          {/* This week */}
          <section className="mb-8">
            <SectionHeader title="This week" />
            <div className="grid grid-cols-3 gap-2.5">
              <StatTile
                icon={<Route className="w-4 h-4" strokeWidth={1.75} />}
                value={dashboardData.weeklyStats.ecoTrips}
                label="Eco trips"
              />
              <StatTile
                icon={<Leaf className="w-4 h-4" strokeWidth={1.75} />}
                value={dashboardData.weeklyStats.carbonSaved.toFixed(1)}
                label="kg CO₂"
              />
              <StatTile
                icon={<Target className="w-4 h-4" strokeWidth={1.75} />}
                value={`${dashboardData.weeklyStats.goalProgress}%`}
                label="Goal"
              />
            </div>
            <Card className="rounded-2xl mt-3 border-[color:var(--app-line)] shadow-elev-1">
              <CardContent className="p-4 flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-secondary flex items-center justify-center">
                  <Bike className="w-4 h-4 text-muted-foreground" strokeWidth={1.75} />
                </div>
                <div className="flex-1">
                  <div className="text-[11px] uppercase tracking-wider text-muted-foreground">
                    Favourite mode
                  </div>
                  <div className="text-[15px] font-semibold text-foreground">
                    {TRANSPORT_MODES[
                      dashboardData.weeklyStats.favoriteMode as TransportMode
                    ]?.name || "Cycling"}
                  </div>
                </div>
              </CardContent>
            </Card>
          </section>

          {/* Monthly progress */}
          <section className="mb-8">
            <SectionHeader title="Monthly progress" />
            <Card className="rounded-2xl border-[color:var(--app-line)] shadow-elev-1">
              <CardContent className="p-6">
                <div className="flex items-center justify-center mb-6">
                  <ProgressRing progress={monthlyProgress} size={120}>
                    <div className="text-center">
                      <div className="font-display text-[28px] leading-none text-foreground tabular-nums">
                        {Math.round(monthlyProgress)}
                        <span className="text-base text-muted-foreground">%</span>
                      </div>
                      <div className="text-[10px] uppercase tracking-wider text-muted-foreground mt-1">
                        of goal
                      </div>
                    </div>
                  </ProgressRing>
                </div>

                <div className="grid grid-cols-3 gap-2 text-center">
                  <div>
                    <div className="font-display text-xl text-foreground tabular-nums">
                      {Math.round(dashboardData.stats.totalCarbonSaved)}
                    </div>
                    <div className="text-[11px] uppercase tracking-wider text-muted-foreground mt-0.5">
                      kg saved
                    </div>
                  </div>
                  <div>
                    <div className="font-display text-xl text-foreground tabular-nums">
                      {dashboardData.stats.totalTrips}
                    </div>
                    <div className="text-[11px] uppercase tracking-wider text-muted-foreground mt-0.5">
                      Total trips
                    </div>
                  </div>
                  <div>
                    <div className="font-display text-xl text-foreground tabular-nums">
                      {dashboardData.stats.currentStreak}
                    </div>
                    <div className="text-[11px] uppercase tracking-wider text-muted-foreground mt-0.5">
                      Day streak
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </section>

          {/* Achievements rail */}
          {dashboardData.recentAchievements.length > 0 && (
            <section className="mb-8">
              <SectionHeader title="Achievements" linkTo="/profile" linkLabel="See all" />
              <div className="flex gap-3 overflow-x-auto -mx-5 px-5 pb-2 scrollbar-none">
                {dashboardData.recentAchievements.map((achievement) => (
                  <div
                    key={achievement.id}
                    className={`flex-shrink-0 bg-gradient-to-br ${getAchievementGradient(
                      achievement.achievementType,
                    )} text-white p-4 rounded-2xl w-36 shadow-elev-1`}
                  >
                    <div className="text-2xl mb-2">{achievement.icon}</div>
                    <div className="text-[13px] font-semibold leading-tight">
                      {achievement.title}
                    </div>
                    <div className="text-[11px] text-white/70 mt-1 leading-snug">
                      {achievement.description}
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}

          {/* Recent trips */}
          <section className="mb-8">
            <SectionHeader title="Recent trips" linkTo="/trips" linkLabel="History" />
            <div className="space-y-2">
              {dashboardData.recentTrips.map((trip) => {
                const mode = TRANSPORT_MODES[trip.transportMode as TransportMode];
                return (
                  <Card
                    key={trip.id}
                    className="rounded-2xl border-[color:var(--app-line)] shadow-elev-1"
                  >
                    <CardContent className="p-3.5 flex items-center gap-3">
                      <div className="w-11 h-11 rounded-xl bg-secondary flex items-center justify-center text-lg">
                        {mode?.icon || "🚗"}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2 mb-1">
                          <span className="font-medium text-foreground text-[14px] truncate">
                            {trip.startLocation} → {trip.endLocation}
                          </span>
                          <span className="text-[11px] text-muted-foreground shrink-0">
                            {formatTimeAgo(trip.date)}
                          </span>
                        </div>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground tabular-nums">
                          <span>{trip.distance.toFixed(1)} km</span>
                          <span>·</span>
                          <span className="text-[color:var(--app-sage)] font-semibold">
                            −{trip.carbonSaved.toFixed(1)} kg CO₂
                          </span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </section>

          {/* Eco tip */}
          <section className="mb-8">
            <div className="rounded-2xl bg-[color:var(--app-sage-soft)] border border-[color:var(--app-sage)]/15 p-4">
              <div className="flex items-center gap-2 mb-2">
                <Sparkles
                  className="w-4 h-4 text-[color:var(--app-sage)]"
                  strokeWidth={1.75}
                />
                <span className="text-[11px] uppercase tracking-[0.16em] text-[color:var(--app-sage)] font-semibold">
                  Daily tip
                </span>
              </div>
              <p className="text-[14px] leading-relaxed text-foreground/85">
                Combine errands into a single bike ride instead of several short
                car trips — you could avoid up to <strong>5 kg</strong> of CO₂
                this week.
              </p>
            </div>
          </section>
        </main>
      </div>

      {/* Floating action button */}
      <Link to="/log-trip">
        <button
          aria-label="Log trip"
          className="fixed bottom-24 right-5 w-14 h-14 bg-[color:var(--app-ink)] hover:bg-[color:var(--app-ink-soft)] text-white rounded-full shadow-ink flex items-center justify-center z-40 transition-transform hover:scale-105 active:scale-95"
        >
          <Plus className="w-6 h-6" strokeWidth={2.25} />
        </button>
      </Link>
    </div>
  );
}

/* — small helpers — */

function SectionHeader({
  title,
  linkTo,
  linkLabel,
}: {
  title: string;
  linkTo?: string;
  linkLabel?: string;
}) {
  return (
    <div className="flex items-baseline justify-between mb-3">
      <h2 className="text-[15px] font-semibold text-foreground tracking-tight">
        {title}
      </h2>
      {linkTo && linkLabel && (
        <Link to={linkTo}>
          <button className="text-[12px] text-muted-foreground hover:text-foreground font-medium">
            {linkLabel}
          </button>
        </Link>
      )}
    </div>
  );
}

function StatTile({
  icon,
  value,
  label,
}: {
  icon: React.ReactNode;
  value: React.ReactNode;
  label: string;
}) {
  return (
    <Card className="rounded-2xl border-[color:var(--app-line)] shadow-elev-1">
      <CardContent className="p-3">
        <div className="w-7 h-7 rounded-lg bg-secondary flex items-center justify-center text-muted-foreground mb-2">
          {icon}
        </div>
        <div className="font-display text-lg leading-none text-foreground tabular-nums">
          {value}
        </div>
        <div className="text-[10.5px] uppercase tracking-wider text-muted-foreground mt-1">
          {label}
        </div>
      </CardContent>
    </Card>
  );
}
