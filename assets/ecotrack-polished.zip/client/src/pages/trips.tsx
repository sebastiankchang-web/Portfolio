import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, Calendar, MapPin } from "lucide-react";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { TRANSPORT_MODES, type TransportMode } from "@/lib/carbon-calculator";
import { useCurrentUser } from "@/hooks/use-current-user";

interface Trip {
  id: number;
  transportMode: string;
  startLocation: string;
  endLocation: string;
  distance: number;
  carbonSaved: number;
  date: string;
}

function formatDate(dateString: string) {
  const date = new Date(dateString);
  const now = new Date();
  const diffInDays = Math.floor(
    (now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24),
  );
  if (diffInDays === 0) return "Today";
  if (diffInDays === 1) return "Yesterday";
  if (diffInDays < 7) return `${diffInDays} days ago`;
  return date.toLocaleDateString(undefined, {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}

function groupTripsByDate(trips: Trip[]) {
  const groups: { [key: string]: Trip[] } = {};
  trips.forEach((trip) => {
    const date = new Date(trip.date);
    const dateKey = date.toDateString();
    if (!groups[dateKey]) groups[dateKey] = [];
    groups[dateKey].push(trip);
  });
  return Object.entries(groups).sort(
    ([a], [b]) => new Date(b).getTime() - new Date(a).getTime(),
  );
}

export default function Trips() {
  const { data: currentUser } = useCurrentUser();
  const userId = currentUser?.id;

  const { data: trips, isLoading } = useQuery<Trip[]>({
    queryKey: [`/api/user/${userId}/trips`],
    enabled: !!userId,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-7 h-7 border-[2.5px] border-[color:var(--app-sage)] border-t-transparent rounded-full animate-spin mx-auto mb-3" />
          <p className="text-sm text-muted-foreground">Loading your trips…</p>
        </div>
      </div>
    );
  }

  if (!trips || trips.length === 0) {
    return (
      <div className="min-h-screen bg-background pb-24 safe-area-bottom">
        <div className="max-w-sm mx-auto bg-background min-h-screen">
          <TripsHeader trips={[]} />
          <main className="px-5 py-12">
            <div className="text-center">
              <div className="text-5xl mb-4">🌱</div>
              <h3 className="text-[15px] font-semibold text-foreground mb-1">
                No trips yet
              </h3>
              <p className="text-sm text-muted-foreground mb-6 max-w-[260px] mx-auto">
                Start logging your sustainable journeys and watch the savings
                add up.
              </p>
              <Link to="/log-trip">
                <button className="bg-[color:var(--app-ink)] hover:bg-[color:var(--app-ink-soft)] text-white px-6 py-3 rounded-full font-medium">
                  Log your first trip
                </button>
              </Link>
            </div>
          </main>
        </div>
      </div>
    );
  }

  const groupedTrips = groupTripsByDate(trips);

  return (
    <div className="min-h-screen bg-background pb-24 safe-area-bottom">
      <div className="max-w-sm mx-auto bg-background min-h-screen ios-scroll">
        <TripsHeader trips={trips} />

        <main className="px-5 py-6">
          <div className="space-y-6">
            {groupedTrips.map(([dateKey, dateTrips]) => {
              const dayCarbon = dateTrips.reduce(
                (sum, t) => sum + t.carbonSaved,
                0,
              );
              return (
                <div key={dateKey}>
                  <div className="flex items-center gap-2 mb-3">
                    <Calendar
                      className="w-3.5 h-3.5 text-muted-foreground"
                      strokeWidth={1.75}
                    />
                    <h3 className="text-[12px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
                      {formatDate(dateKey)}
                    </h3>
                    <div className="flex-1 h-px bg-[color:var(--app-line)]" />
                    <span className="text-[11px] text-[color:var(--app-sage)] font-semibold tabular-nums">
                      −{dayCarbon.toFixed(1)} kg
                    </span>
                  </div>
                  <div className="space-y-2">
                    {dateTrips.map((trip) => {
                      const mode =
                        TRANSPORT_MODES[trip.transportMode as TransportMode];
                      return (
                        <Card
                          key={trip.id}
                          className="rounded-2xl border-[color:var(--app-line)] shadow-elev-1"
                        >
                          <CardContent className="p-4">
                            <div className="flex items-center gap-3.5">
                              <div className="w-12 h-12 rounded-xl bg-secondary flex items-center justify-center text-xl shrink-0">
                                {mode?.icon || "🚗"}
                              </div>
                              <div className="flex-1 min-w-0">
                                <div className="flex items-start justify-between gap-2 mb-1">
                                  <div className="flex items-center gap-1.5 min-w-0">
                                    <MapPin
                                      className="w-3.5 h-3.5 text-muted-foreground shrink-0"
                                      strokeWidth={1.75}
                                    />
                                    <span className="font-medium text-[14px] text-foreground truncate">
                                      {trip.startLocation} → {trip.endLocation}
                                    </span>
                                  </div>
                                  <div className="text-[13px] font-semibold text-[color:var(--app-sage)] tabular-nums shrink-0">
                                    −{trip.carbonSaved.toFixed(1)} kg
                                  </div>
                                </div>
                                <div className="flex items-center justify-between text-xs text-muted-foreground">
                                  <span>{mode?.name || "Unknown"}</span>
                                  <span className="tabular-nums">
                                    {trip.distance.toFixed(1)} km
                                  </span>
                                </div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </main>
      </div>
    </div>
  );
}

function TripsHeader({ trips }: { trips: Trip[] }) {
  const totalCarbon = trips.reduce((sum, t) => sum + t.carbonSaved, 0);
  return (
    <header className="bg-[color:var(--app-ink)] text-white px-5 pt-4 pb-6 rounded-b-[28px] shadow-ink ring-hairline safe-area-top">
      <div className="flex items-center gap-3 mb-5">
        <Link to="/">
          <button
            aria-label="Back"
            className="w-10 h-10 rounded-full bg-white/10 hover:bg-white/15 flex items-center justify-center transition-colors"
          >
            <ArrowLeft className="w-5 h-5" strokeWidth={1.75} />
          </button>
        </Link>
        <div>
          <p className="text-[10px] uppercase tracking-[0.18em] text-white/60">
            Journal
          </p>
          <h1 className="text-[20px] font-semibold leading-tight">
            Trip history
          </h1>
        </div>
      </div>
      <div className="rounded-2xl bg-white/8 backdrop-blur-sm p-4 grid grid-cols-2 gap-4">
        <div className="text-center">
          <div className="font-display text-[26px] leading-none tabular-nums">
            {trips.length}
          </div>
          <div className="text-[10px] uppercase tracking-wider text-white/65 mt-1.5">
            Total trips
          </div>
        </div>
        <div className="text-center">
          <div className="font-display text-[26px] leading-none tabular-nums">
            {totalCarbon.toFixed(1)}
          </div>
          <div className="text-[10px] uppercase tracking-wider text-white/65 mt-1.5">
            kg CO₂ saved
          </div>
        </div>
      </div>
    </header>
  );
}
