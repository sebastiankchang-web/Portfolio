import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { ArrowLeft, MapPin, Navigation } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import {
  TRANSPORT_MODES,
  type TransportMode,
  calculateCarbonSaved,
  getCarbonSavingsMessage,
} from "@/lib/carbon-calculator";
import { LocationSearch } from "@/components/location-search";
import { MapComponent } from "@/components/map-component";
import { useCurrentUser } from "@/hooks/use-current-user";

interface TripForm {
  transportMode: TransportMode;
  startLocation: string;
  endLocation: string;
  distance: number;
}

interface LocationData {
  name: string;
  coords: [number, number];
}

interface RouteOption {
  geometry: any;
  duration: number;
  distance: number;
  profile: string;
}

export default function LogTrip() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { data: currentUser } = useCurrentUser();
  const userId = currentUser?.id;

  const [form, setForm] = useState<TripForm>({
    transportMode: "cycling",
    startLocation: "",
    endLocation: "",
    distance: 0,
  });

  const [startLocationData, setStartLocationData] =
    useState<LocationData | null>(null);
  const [endLocationData, setEndLocationData] = useState<LocationData | null>(
    null,
  );
  const [showMap, setShowMap] = useState(false);
  const [selectedRoute, setSelectedRoute] = useState<RouteOption | null>(null);

  const createTripMutation = useMutation({
    mutationFn: async (tripData: TripForm) => {
      const response = await apiRequest(
        "POST",
        `/api/user/${userId}/trips`,
        tripData,
      );
      return response.json();
    },
    onSuccess: () => {
      const carbonSaved = calculateCarbonSaved(form.transportMode, form.distance);
      toast({
        title: "Trip logged",
        description: `You saved ${carbonSaved.toFixed(1)} kg of CO₂.`,
      });
      queryClient.invalidateQueries({
        queryKey: [`/api/user/${userId}/dashboard`],
      });
      queryClient.invalidateQueries({
        queryKey: [`/api/user/${userId}/trips`],
      });
      setLocation("/");
    },
    onError: () => {
      toast({
        title: "Couldn't log your trip",
        description: "Please try again in a moment.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.startLocation || !form.endLocation || form.distance <= 0) {
      toast({
        title: "A few details still needed",
        description: "Fill in From, To, and Distance to log the trip.",
        variant: "destructive",
      });
      return;
    }
    createTripMutation.mutate(form);
  };

  const updateForm = (field: keyof TripForm, value: any) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const calculateDistanceFromCoords = (
    start: [number, number],
    end: [number, number],
  ) => {
    const R = 6371;
    const dLat = ((end[1] - start[1]) * Math.PI) / 180;
    const dLon = ((end[0] - start[0]) * Math.PI) / 180;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((start[1] * Math.PI) / 180) *
        Math.cos((end[1] * Math.PI) / 180) *
        Math.sin(dLon / 2) *
        Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  };

  const handleStartLocationSelect = (location: any) => {
    const data: LocationData = {
      name: location.place_name,
      coords: location.center,
    };
    setStartLocationData(data);
    updateForm("startLocation", location.place_name);
    if (endLocationData) {
      const distance = calculateDistanceFromCoords(
        location.center,
        endLocationData.coords,
      );
      updateForm("distance", Number(distance.toFixed(1)));
    }
    setShowMap(true);
  };

  const handleEndLocationSelect = (location: any) => {
    const data: LocationData = {
      name: location.place_name,
      coords: location.center,
    };
    setEndLocationData(data);
    updateForm("endLocation", location.place_name);
    if (startLocationData) {
      const distance = calculateDistanceFromCoords(
        startLocationData.coords,
        location.center,
      );
      updateForm("distance", Number(distance.toFixed(1)));
    }
    setShowMap(true);
  };

  const handleRouteSelect = (route: RouteOption) => {
    setSelectedRoute(route);
    updateForm("distance", Number(route.distance.toFixed(1)));
  };

  const formatDuration = (seconds: number) => {
    if (seconds < 3600) return `${Math.round(seconds / 60)} min`;
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.round((seconds % 3600) / 60);
    return `${hours} h ${minutes} m`;
  };

  const estimatedCarbonSaved =
    form.distance > 0
      ? calculateCarbonSaved(form.transportMode, form.distance)
      : 0;

  return (
    <div className="min-h-screen bg-background pb-24 safe-area-bottom">
      <div className="max-w-sm mx-auto bg-background min-h-screen ios-scroll">
        {/* Header */}
        <header className="bg-[color:var(--app-ink)] text-white px-5 pt-4 pb-6 rounded-b-[28px] shadow-ink ring-hairline safe-area-top">
          <div className="flex items-center gap-3">
            <button
              aria-label="Back"
              onClick={() => setLocation("/")}
              className="w-10 h-10 rounded-full bg-white/10 hover:bg-white/15 flex items-center justify-center transition-colors"
            >
              <ArrowLeft className="w-5 h-5" strokeWidth={1.75} />
            </button>
            <div>
              <p className="text-[10px] uppercase tracking-[0.18em] text-white/60">
                New entry
              </p>
              <h1 className="text-[20px] font-semibold leading-tight">
                Log a trip
              </h1>
            </div>
          </div>
        </header>

        <main className="px-5 py-6">
          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Transport mode */}
            <Card className="rounded-2xl border-[color:var(--app-line)] shadow-elev-1">
              <CardHeader className="pb-2">
                <CardTitle className="text-[15px] font-semibold">
                  How did you travel?
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-2">
                  {Object.entries(TRANSPORT_MODES).map(([mode, info]) => {
                    const selected = form.transportMode === mode;
                    return (
                      <button
                        key={mode}
                        type="button"
                        onClick={() => updateForm("transportMode", mode)}
                        className={`p-3 rounded-xl border text-center transition-all ${
                          selected
                            ? "border-[color:var(--app-ink)] bg-secondary"
                            : "border-[color:var(--app-line)] bg-white hover:border-[color:var(--app-ink-soft)]"
                        }`}
                      >
                        <div className="text-xl mb-1.5">{info.icon}</div>
                        <div className="text-[11px] font-medium text-foreground leading-tight">
                          {info.name}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            {/* Trip details */}
            <Card className="rounded-2xl border-[color:var(--app-line)] shadow-elev-1">
              <CardHeader className="pb-2">
                <CardTitle className="text-[15px] font-semibold flex items-center">
                  <Navigation
                    className="w-4 h-4 mr-2 text-[color:var(--app-sage)]"
                    strokeWidth={1.75}
                  />
                  Route
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label
                    htmlFor="start"
                    className="text-[11px] uppercase tracking-wider text-muted-foreground mb-2 block"
                  >
                    From
                  </Label>
                  <LocationSearch
                    placeholder="Search starting location"
                    value={form.startLocation}
                    onLocationSelect={handleStartLocationSelect}
                    onInputChange={(value) => updateForm("startLocation", value)}
                  />
                </div>

                <div>
                  <Label
                    htmlFor="end"
                    className="text-[11px] uppercase tracking-wider text-muted-foreground mb-2 block"
                  >
                    To
                  </Label>
                  <LocationSearch
                    placeholder="Search destination"
                    value={form.endLocation}
                    onLocationSelect={handleEndLocationSelect}
                    onInputChange={(value) => updateForm("endLocation", value)}
                  />
                </div>

                <div>
                  <Label
                    htmlFor="distance"
                    className="text-[11px] uppercase tracking-wider text-muted-foreground mb-2 block"
                  >
                    Distance (km)
                  </Label>
                  <Input
                    id="distance"
                    type="number"
                    step="0.1"
                    min="0"
                    placeholder="0.0"
                    value={form.distance || ""}
                    onChange={(e) =>
                      updateForm("distance", parseFloat(e.target.value) || 0)
                    }
                    className="rounded-xl border-[color:var(--app-line)] focus:border-[color:var(--app-sage)] focus:ring-[color:var(--app-sage)]/30"
                  />
                  {startLocationData && endLocationData && (
                    <p className="text-[11px] text-muted-foreground mt-1.5">
                      {selectedRoute
                        ? `Distance from your selected ${form.transportMode} route.`
                        : "Distance calculated from the chosen locations."}
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Map */}
            {showMap && (startLocationData || endLocationData) && (
              <Card className="rounded-2xl border-[color:var(--app-line)] shadow-elev-1 overflow-hidden">
                <CardHeader className="pb-2">
                  <CardTitle className="text-[15px] font-semibold flex items-center">
                    <MapPin
                      className="w-4 h-4 mr-2 text-[color:var(--app-sage)]"
                      strokeWidth={1.75}
                    />
                    Route preview
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  <MapComponent
                    startCoords={startLocationData?.coords}
                    endCoords={endLocationData?.coords}
                    showRoute={!!(startLocationData && endLocationData)}
                    transportMode={form.transportMode}
                    onRouteSelect={handleRouteSelect}
                    height="250px"
                  />
                  {selectedRoute && (
                    <div className="p-4 bg-secondary/60 border-t border-[color:var(--app-line)]">
                      <div className="text-[11px] uppercase tracking-wider text-muted-foreground mb-2">
                        Selected route
                      </div>
                      <div className="flex items-center justify-between text-sm tabular-nums">
                        <span className="font-semibold text-foreground">
                          {selectedRoute.distance.toFixed(1)} km
                        </span>
                        <span className="text-muted-foreground">
                          {formatDuration(selectedRoute.duration)}
                        </span>
                        <span className="text-[11px] bg-white border border-[color:var(--app-line)] px-2 py-1 rounded-full capitalize">
                          {selectedRoute.profile}
                        </span>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Impact preview */}
            {form.distance > 0 && (
              <Card className="rounded-2xl bg-[color:var(--app-sage-soft)] border-[color:var(--app-sage)]/15 shadow-elev-1">
                <CardContent className="p-6 text-center">
                  <div className="font-display text-[42px] leading-none text-foreground tabular-nums">
                    {estimatedCarbonSaved.toFixed(1)}
                    <span className="text-base text-muted-foreground ml-1.5">
                      kg CO₂
                    </span>
                  </div>
                  <p className="text-[12px] uppercase tracking-wider text-[color:var(--app-sage)] font-semibold mt-3">
                    Estimated carbon saved
                  </p>
                  <p className="text-[13px] text-foreground/70 mt-2 max-w-[280px] mx-auto">
                    {getCarbonSavingsMessage(estimatedCarbonSaved)}
                  </p>
                </CardContent>
              </Card>
            )}

            {/* Submit */}
            <Button
              type="submit"
              disabled={createTripMutation.isPending}
              className="w-full bg-[color:var(--app-ink)] hover:bg-[color:var(--app-ink-soft)] text-white h-14 rounded-2xl font-semibold text-base shadow-ink"
            >
              {createTripMutation.isPending ? (
                <div className="flex items-center justify-center">
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                  Logging…
                </div>
              ) : (
                "Log trip"
              )}
            </Button>
          </form>
        </main>
      </div>
    </div>
  );
}
