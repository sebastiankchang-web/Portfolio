import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Search, UserPlus, Users, ArrowLeft, UserCheck } from "lucide-react";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { UserAvatar } from "@/components/user-avatar";
import { apiRequest } from "@/lib/queryClient";
import { useCurrentUser } from "@/hooks/use-current-user";

interface User {
  id: number;
  username: string;
  displayName: string;
  profileImageUrl?: string;
  bio?: string;
}

interface Follow {
  id: number;
  followerId: number;
  followingId: number;
  createdAt: string;
  following: User;
}

export default function Social() {
  const [searchQuery, setSearchQuery] = useState("");
  const queryClient = useQueryClient();
  const { data: currentUser } = useCurrentUser();
  const userId = currentUser?.id;

  const { data: searchResults, isLoading: isSearching } = useQuery<User[]>({
    queryKey: ["/api/users/search", searchQuery],
    enabled: searchQuery.length > 2,
  });

  const { data: following } = useQuery<Follow[]>({
    queryKey: [`/api/user/${userId}/following`],
    enabled: !!userId,
  });

  const followMutation = useMutation({
    mutationFn: async (followingId: number) => {
      const response = await apiRequest(
        "POST",
        `/api/user/${userId}/follow`,
        { followingId },
      );
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: [`/api/user/${userId}/following`],
      });
      queryClient.invalidateQueries({
        queryKey: [`/api/user/${userId}/dashboard`],
      });
    },
  });

  const unfollowMutation = useMutation({
    mutationFn: async (followingId: number) => {
      await apiRequest("DELETE", `/api/user/${userId}/follow/${followingId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: [`/api/user/${userId}/following`],
      });
      queryClient.invalidateQueries({
        queryKey: [`/api/user/${userId}/dashboard`],
      });
    },
  });

  const isFollowing = (id: number) =>
    following?.some((f) => f.followingId === id) ?? false;

  const handleFollowToggle = (id: number) => {
    if (isFollowing(id)) unfollowMutation.mutate(id);
    else followMutation.mutate(id);
  };

  return (
    <div className="min-h-screen bg-background pb-24 safe-area-bottom">
      <div className="max-w-sm mx-auto bg-background min-h-screen ios-scroll">
        {/* Header */}
        <header className="px-5 pt-4 pb-3 sticky top-0 z-20 bg-background/85 backdrop-blur-xl border-b border-[color:var(--app-line)]/70 safe-area-top">
          <div className="flex items-center gap-3">
            <Link to="/">
              <button
                aria-label="Back"
                className="w-10 h-10 rounded-full bg-secondary hover:bg-secondary/80 flex items-center justify-center transition-colors"
              >
                <ArrowLeft className="w-5 h-5 text-foreground/70" strokeWidth={1.75} />
              </button>
            </Link>
            <div>
              <p className="text-[10px] uppercase tracking-[0.16em] text-muted-foreground">
                Discover
              </p>
              <h1 className="text-[17px] font-semibold text-foreground leading-tight">
                Find your tribe
              </h1>
            </div>
          </div>
        </header>

        {/* Search */}
        <div className="p-5 pb-3">
          <div className="relative">
            <Search
              className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground"
              strokeWidth={1.75}
            />
            <Input
              type="text"
              placeholder="Search by name or @username"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 pr-4 h-12 rounded-2xl bg-secondary/60 border-transparent
                         focus-visible:border-[color:var(--app-sage)]
                         focus-visible:ring-[color:var(--app-sage)]/30
                         placeholder:text-muted-foreground/70"
            />
          </div>
        </div>

        {/* Following */}
        <div className="px-5 mb-6">
          <SectionHeader
            title="Following"
            trailing={
              <span className="flex items-center gap-1 text-xs text-muted-foreground tabular-nums">
                <Users className="w-3.5 h-3.5" strokeWidth={1.75} />
                {following?.length ?? 0}
              </span>
            }
          />

          {following && following.length > 0 ? (
            <div className="space-y-2">
              {following.map((follow) => (
                <UserRow
                  key={follow.id}
                  user={follow.following}
                  trailing={
                    <Button
                      onClick={() => handleFollowToggle(follow.following.id)}
                      variant="outline"
                      size="sm"
                      className="rounded-full border-[color:var(--app-line)] text-foreground/70
                                 hover:bg-rose-50 hover:border-rose-200 hover:text-rose-600"
                      disabled={unfollowMutation.isPending}
                    >
                      <UserCheck className="w-3.5 h-3.5 mr-1" strokeWidth={1.75} />
                      Following
                    </Button>
                  }
                />
              ))}
            </div>
          ) : (
            <EmptyState
              icon={<Users className="w-8 h-8" strokeWidth={1.25} />}
              title="No one yet"
              caption="Search above to follow eco-conscious people."
            />
          )}
        </div>

        {/* Search results */}
        {searchQuery.length > 2 && (
          <div className="px-5">
            <SectionHeader title="Results" />

            {isSearching ? (
              <div className="flex justify-center py-8">
                <div className="w-5 h-5 border-2 border-[color:var(--app-sage)] border-t-transparent rounded-full animate-spin" />
              </div>
            ) : searchResults && searchResults.length > 0 ? (
              <div className="space-y-2">
                {searchResults
                  .filter((u) => u.id !== userId)
                  .map((user) => {
                    const followed = isFollowing(user.id);
                    return (
                      <UserRow
                        key={user.id}
                        user={user}
                        trailing={
                          <Button
                            onClick={() => handleFollowToggle(user.id)}
                            size="sm"
                            className={`rounded-full ${
                              followed
                                ? "bg-secondary text-foreground hover:bg-rose-50 hover:text-rose-600"
                                : "bg-[color:var(--app-ink)] text-white hover:bg-[color:var(--app-ink-soft)]"
                            }`}
                            disabled={
                              followMutation.isPending || unfollowMutation.isPending
                            }
                          >
                            {followed ? (
                              <>
                                <UserCheck className="w-3.5 h-3.5 mr-1" strokeWidth={1.75} />
                                Following
                              </>
                            ) : (
                              <>
                                <UserPlus className="w-3.5 h-3.5 mr-1" strokeWidth={1.75} />
                                Follow
                              </>
                            )}
                          </Button>
                        }
                      />
                    );
                  })}
              </div>
            ) : (
              <EmptyState
                icon={<Search className="w-8 h-8" strokeWidth={1.25} />}
                title="No one matched that"
                caption="Try a different name or username."
              />
            )}
          </div>
        )}

        {/* Suggestions */}
        {searchQuery.length <= 2 && (
          <div className="px-5">
            <SectionHeader title="Suggested for you" />
            <EmptyState
              icon={<UserPlus className="w-8 h-8" strokeWidth={1.25} />}
              title="Find your people"
              caption="Search by name to follow friends and fellow sustainability fans."
            />
          </div>
        )}
      </div>
    </div>
  );
}

/* — helpers — */

function SectionHeader({
  title,
  trailing,
}: {
  title: string;
  trailing?: React.ReactNode;
}) {
  return (
    <div className="flex items-baseline justify-between mb-3">
      <h2 className="text-[15px] font-semibold text-foreground tracking-tight">
        {title}
      </h2>
      {trailing}
    </div>
  );
}

function UserRow({
  user,
  trailing,
}: {
  user: User;
  trailing: React.ReactNode;
}) {
  return (
    <Card className="rounded-2xl border-[color:var(--app-line)] shadow-elev-1">
      <CardContent className="p-3.5">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <UserAvatar
              src={user.profileImageUrl}
              name={user.displayName}
              size={44}
            />
            <div className="min-w-0">
              <h3 className="font-semibold text-foreground text-[14px] truncate">
                {user.displayName}
              </h3>
              <p className="text-xs text-muted-foreground truncate">
                @{user.username}
              </p>
              {user.bio && (
                <p className="text-[11.5px] text-muted-foreground mt-0.5 line-clamp-1">
                  {user.bio}
                </p>
              )}
            </div>
          </div>
          {trailing}
        </div>
      </CardContent>
    </Card>
  );
}

function EmptyState({
  icon,
  title,
  caption,
}: {
  icon: React.ReactNode;
  title: string;
  caption: string;
}) {
  return (
    <div className="text-center py-10">
      <div className="text-muted-foreground/50 inline-flex mb-3">{icon}</div>
      <p className="text-foreground/85 text-sm font-medium">{title}</p>
      <p className="text-xs text-muted-foreground mt-1 max-w-[240px] mx-auto">
        {caption}
      </p>
    </div>
  );
}
