import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, Settings, Trophy, Target, Leaf, Sparkles } from "lucide-react";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { UserAvatar } from "@/components/user-avatar";
import { useCurrentUser } from "@/hooks/use-current-user";

interface Achievement {
  id: number;
  achievementType: string;
  title: string;
  description: string;
  icon: string;
  unlockedAt: string;
}

interface UserStats {
  totalCarbonSaved: number;
  totalTrips: number;
  currentStreak: number;
  longestStreak: number;
  monthlyGoal: number;
}

export default function Profile() {
  const { data: currentUser } = useCurrentUser();
  const userId = currentUser?.id;

  const { data: achievements, isLoading: loadingAchievements } = useQuery<
    Achievement[]
  >({
    queryKey: [`/api/user/${userId}/achievements`],
    enabled: !!userId,
  });

  const { data: stats, isLoading: loadingStats } = useQuery<UserStats>({
    queryKey: [`/api/user/${userId}/stats`],
    enabled: !!userId,
  });

  const isLoading = loadingAchievements || loadingStats;

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-7 h-7 border-[2.5px] border-[color:var(--app-sage)] border-t-transparent rounded-full animate-spin mx-auto mb-3" />
          <p className="text-sm text-muted-foreground">Loading your profile…</p>
        </div>
      </div>
    );
  }

  const monthlyPct = stats
    ? Math.min(100, Math.round((stats.totalCarbonSaved / stats.monthlyGoal) * 100))
    : 0;

  return (
    <div className="min-h-screen bg-background pb-24 safe-area-bottom">
      <div className="max-w-sm mx-auto bg-background min-h-screen ios-scroll">
        {/* Header */}
        <header className="bg-[color:var(--app-ink)] text-white px-5 pt-4 pb-7 rounded-b-[28px] shadow-ink ring-hairline safe-area-top">
          <div className="flex items-center justify-between mb-6">
            <Link to="/">
              <button
                aria-label="Back"
                className="w-10 h-10 rounded-full bg-white/10 hover:bg-white/15 flex items-center justify-center transition-colors"
              >
                <ArrowLeft className="w-5 h-5" strokeWidth={1.75} />
              </button>
            </Link>
            <div className="text-center">
              <p className="text-[10px] uppercase tracking-[0.18em] text-white/60">
                Profile
              </p>
              <p className="text-sm font-medium">Your eco journey</p>
            </div>
            <button
              aria-label="Settings"
              className="w-10 h-10 rounded-full bg-white/10 hover:bg-white/15 flex items-center justify-center transition-colors"
            >
              <Settings className="w-5 h-5" strokeWidth={1.75} />
            </button>
          </div>

          <div className="flex flex-col items-center text-center">
            <UserAvatar
              src={currentUser?.profileImageUrl}
              name={currentUser?.displayName}
              size={96}
              ringClassName="ring-2 ring-white/15"
            />
            <h2 className="text-[22px] font-semibold mt-4">
              {currentUser?.displayName || "User"}
            </h2>
            <p className="text-white/65 text-sm">@{currentUser?.username}</p>
            {currentUser?.bio && (
              <p className="text-white/80 text-[13px] mt-2 max-w-[260px] leading-snug">
                {currentUser.bio}
              </p>
            )}

            {stats && (
              <div className="mt-5 grid grid-cols-3 w-full gap-2">
                <StatPill value={stats.totalTrips} label="Trips" />
                <StatPill value={stats.totalCarbonSaved.toFixed(0)} label="kg CO₂" />
                <StatPill value={stats.currentStreak} label="Day streak" />
              </div>
            )}
          </div>
        </header>

        <main className="px-5 py-6 space-y-6">
          {stats && (
            <Card className="rounded-2xl border-[color:var(--app-line)] shadow-elev-1">
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center text-[15px] font-semibold">
                  <Target
                    className="w-4 h-4 mr-2 text-[color:var(--app-sage)]"
                    strokeWidth={1.75}
                  />
                  Your goals
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <GoalRow
                  icon={<Leaf className="w-4 h-4" strokeWidth={1.75} />}
                  title="Monthly goal"
                  caption={`Save ${stats.monthlyGoal} kg CO₂`}
                  trailing={
                    <Badge
                      variant="secondary"
                      className="bg-[color:var(--app-sage-soft)] text-[color:var(--app-sage)] border-0 tabular-nums"
                    >
                      {monthlyPct}%
                    </Badge>
                  }
                />
                <GoalRow
                  icon={<Trophy className="w-4 h-4" strokeWidth={1.75} />}
                  title="Longest streak"
                  caption={`${stats.longestStreak} days`}
                  trailing={
                    <Badge
                      variant="secondary"
                      className="bg-secondary text-foreground border-0"
                    >
                      Personal best
                    </Badge>
                  }
                />
              </CardContent>
            </Card>
          )}

          <Card className="rounded-2xl border-[color:var(--app-line)] shadow-elev-1">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center text-[15px] font-semibold">
                <Trophy
                  className="w-4 h-4 mr-2 text-[color:var(--app-sage)]"
                  strokeWidth={1.75}
                />
                Achievements
                {achievements && achievements.length > 0 && (
                  <Badge className="ml-2 bg-[color:var(--app-ink)] text-white tabular-nums">
                    {achievements.length}
                  </Badge>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {achievements && achievements.length > 0 ? (
                <div className="grid grid-cols-2 gap-3">
                  {achievements.map((achievement) => (
                    <div
                      key={achievement.id}
                      className="bg-[color:var(--app-ink)] text-white p-4 rounded-2xl shadow-elev-1"
                    >
                      <div className="text-2xl mb-2">{achievement.icon}</div>
                      <div className="text-[13px] font-semibold leading-tight">
                        {achievement.title}
                      </div>
                      <div className="text-[11px] text-white/70 mt-1 leading-snug">
                        {achievement.description}
                      </div>
                      <div className="text-[10px] text-white/45 mt-3">
                        {new Date(achievement.unlockedAt).toLocaleDateString()}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <div className="text-4xl mb-3">🏆</div>
                  <h3 className="font-semibold text-foreground mb-1">
                    No achievements yet
                  </h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Log your first trip to unlock one.
                  </p>
                  <Link to="/log-trip">
                    <button className="bg-[color:var(--app-ink)] hover:bg-[color:var(--app-ink-soft)] text-white px-5 py-2.5 rounded-full text-sm font-medium">
                      Log a trip
                    </button>
                  </Link>
                </div>
              )}
            </CardContent>
          </Card>

          {stats && stats.totalCarbonSaved > 0 && (
            <Card className="rounded-2xl bg-[color:var(--app-sage-soft)] border-[color:var(--app-sage)]/15 shadow-elev-1">
              <CardContent className="p-6">
                <h3 className="text-[15px] font-semibold text-foreground mb-4 flex items-center">
                  <Sparkles
                    className="w-4 h-4 mr-2 text-[color:var(--app-sage)]"
                    strokeWidth={1.75}
                  />
                  Your impact
                </h3>
                <div className="grid grid-cols-2 gap-3">
                  <ImpactTile
                    value={Math.round(stats.totalCarbonSaved * 0.045)}
                    label="Trees planted, equivalent"
                  />
                  <ImpactTile
                    value={Math.round(stats.totalCarbonSaved * 2.4)}
                    label="Miles not driven"
                  />
                </div>
                <p className="text-[13px] text-foreground/70 text-center mt-4">
                  Quiet choices, real difference.
                </p>
              </CardContent>
            </Card>
          )}
        </main>
      </div>
    </div>
  );
}

function StatPill({
  value,
  label,
}: {
  value: number | string;
  label: string;
}) {
  return (
    <div className="rounded-2xl bg-white/8 backdrop-blur-sm px-2 py-3 text-center">
      <div className="font-display text-[20px] leading-none tabular-nums">
        {value}
      </div>
      <div className="text-[10px] uppercase tracking-wider text-white/65 mt-1.5">
        {label}
      </div>
    </div>
  );
}

function GoalRow({
  icon,
  title,
  caption,
  trailing,
}: {
  icon: React.ReactNode;
  title: string;
  caption: string;
  trailing: React.ReactNode;
}) {
  return (
    <div className="flex items-center justify-between p-3 bg-secondary/60 rounded-xl">
      <div className="flex items-center gap-3">
        <div className="w-9 h-9 rounded-lg bg-white flex items-center justify-center text-[color:var(--app-sage)]">
          {icon}
        </div>
        <div>
          <div className="font-medium text-[14px] text-foreground">{title}</div>
          <div className="text-xs text-muted-foreground">{caption}</div>
        </div>
      </div>
      {trailing}
    </div>
  );
}

function ImpactTile({ value, label }: { value: number; label: string }) {
  return (
    <div className="text-center p-3 bg-white rounded-xl border border-[color:var(--app-line)]">
      <div className="font-display text-xl text-foreground tabular-nums">
        {value}
      </div>
      <div className="text-[11px] text-muted-foreground mt-1 leading-snug">
        {label}
      </div>
    </div>
  );
}
