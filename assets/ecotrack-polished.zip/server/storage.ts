import { 
  users, trips, achievements, userStats, posts, follows, likes,
  type User, type InsertUser, type Trip, type InsertTrip, 
  type Achievement, type InsertAchievement, type UserStats, type InsertUserStats,
  type Post, type InsertPost, type Follow, type InsertFollow, type Like, type InsertLike
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, or, sql, exists, count } from "drizzle-orm";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  searchUsers(query: string, limit?: number): Promise<User[]>;
  
  // Trip methods
  createTrip(trip: InsertTrip & { userId: number }): Promise<Trip>;
  getUserTrips(userId: number, limit?: number): Promise<Trip[]>;
  getTripById(id: number): Promise<Trip | undefined>;
  getFeedTrips(userId: number, limit?: number): Promise<(Trip & { user: User })[]>;
  
  // Achievement methods
  createAchievement(achievement: InsertAchievement): Promise<Achievement>;
  getUserAchievements(userId: number): Promise<Achievement[]>;
  
  // Stats methods
  getUserStats(userId: number): Promise<UserStats | undefined>;
  updateUserStats(userId: number, stats: Partial<InsertUserStats>): Promise<UserStats>;
  createUserStats(userId: number, stats: InsertUserStats): Promise<UserStats>;
  
  // Social methods
  followUser(followerId: number, followingId: number): Promise<Follow>;
  unfollowUser(followerId: number, followingId: number): Promise<void>;
  isFollowing(followerId: number, followingId: number): Promise<boolean>;
  getFollowers(userId: number, limit?: number): Promise<(Follow & { follower: User })[]>;
  getFollowing(userId: number, limit?: number): Promise<(Follow & { following: User })[]>;
  
  // Posts methods
  createPost(post: InsertPost): Promise<Post>;
  getFeedPosts(userId: number, limit?: number): Promise<(Post & { user: User; trip?: Trip; likes: Like[]; likeCount: number; isLiked: boolean })[]>;
  likePost(userId: number, postId: number): Promise<Like>;
  unlikePost(userId: number, postId: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    
    // Create initial user stats
    await this.createUserStats(user.id, {
      totalCarbonSaved: 0,
      totalTrips: 0,
      currentStreak: 0,
      longestStreak: 0,
      monthlyGoal: 50,
      followersCount: 0,
      followingCount: 0,
    });
    
    return user;
  }

  async searchUsers(query: string, limit = 20): Promise<User[]> {
    return await db.select()
      .from(users)
      .where(or(
        sql`${users.username} ILIKE ${`%${query}%`}`,
        sql`${users.displayName} ILIKE ${`%${query}%`}`
      ))
      .limit(limit);
  }

  async createTrip(tripData: InsertTrip & { userId: number }): Promise<Trip> {
    const carbonSaved = calculateCarbonSaved(tripData.transportMode, tripData.distance);
    
    const [trip] = await db
      .insert(trips)
      .values({
        ...tripData,
        carbonSaved,
      })
      .returning();
    
    // Update user stats
    const stats = await this.getUserStats(tripData.userId);
    if (stats) {
      await this.updateUserStats(tripData.userId, {
        totalCarbonSaved: stats.totalCarbonSaved + carbonSaved,
        totalTrips: stats.totalTrips + 1,
      });
    }
    
    return trip;
  }

  async getUserTrips(userId: number, limit?: number): Promise<Trip[]> {
    const query = db.select()
      .from(trips)
      .where(eq(trips.userId, userId))
      .orderBy(desc(trips.date));
    
    if (limit) {
      query.limit(limit);
    }
    
    return await query;
  }

  async getTripById(id: number): Promise<Trip | undefined> {
    const [trip] = await db.select().from(trips).where(eq(trips.id, id));
    return trip || undefined;
  }

  async getFeedTrips(userId: number, limit = 20): Promise<(Trip & { user: User })[]> {
    return await db.select({
      id: trips.id,
      userId: trips.userId,
      transportMode: trips.transportMode,
      distance: trips.distance,
      carbonSaved: trips.carbonSaved,
      startLocation: trips.startLocation,
      endLocation: trips.endLocation,
      date: trips.date,
      user: users,
    })
    .from(trips)
    .innerJoin(users, eq(trips.userId, users.id))
    .innerJoin(follows, eq(follows.followingId, trips.userId))
    .where(eq(follows.followerId, userId))
    .orderBy(desc(trips.date))
    .limit(limit);
  }

  async createAchievement(achievementData: InsertAchievement): Promise<Achievement> {
    const [achievement] = await db
      .insert(achievements)
      .values(achievementData)
      .returning();
    
    return achievement;
  }

  async getUserAchievements(userId: number): Promise<Achievement[]> {
    return await db.select()
      .from(achievements)
      .where(eq(achievements.userId, userId))
      .orderBy(desc(achievements.unlockedAt));
  }

  async getUserStats(userId: number): Promise<UserStats | undefined> {
    const [stats] = await db.select().from(userStats).where(eq(userStats.userId, userId));
    return stats || undefined;
  }

  async updateUserStats(userId: number, statsUpdate: Partial<InsertUserStats>): Promise<UserStats> {
    const [updatedStats] = await db
      .update(userStats)
      .set(statsUpdate)
      .where(eq(userStats.userId, userId))
      .returning();
    
    if (!updatedStats) {
      throw new Error("User stats not found");
    }
    
    return updatedStats;
  }

  async createUserStats(userId: number, statsData: InsertUserStats): Promise<UserStats> {
    const [stats] = await db
      .insert(userStats)
      .values({
        ...statsData,
        userId,
      })
      .returning();
    
    return stats;
  }

  // Social methods
  async followUser(followerId: number, followingId: number): Promise<Follow> {
    const [follow] = await db
      .insert(follows)
      .values({ followerId, followingId })
      .returning();

    // Update follower counts
    await Promise.all([
      db.update(userStats)
        .set({ followingCount: sql`${userStats.followingCount} + 1` })
        .where(eq(userStats.userId, followerId)),
      db.update(userStats)
        .set({ followersCount: sql`${userStats.followersCount} + 1` })
        .where(eq(userStats.userId, followingId)),
    ]);

    return follow;
  }

  async unfollowUser(followerId: number, followingId: number): Promise<void> {
    await db.delete(follows)
      .where(and(
        eq(follows.followerId, followerId),
        eq(follows.followingId, followingId)
      ));

    // Update follower counts
    await Promise.all([
      db.update(userStats)
        .set({ followingCount: sql`${userStats.followingCount} - 1` })
        .where(eq(userStats.userId, followerId)),
      db.update(userStats)
        .set({ followersCount: sql`${userStats.followersCount} - 1` })
        .where(eq(userStats.userId, followingId)),
    ]);
  }

  async isFollowing(followerId: number, followingId: number): Promise<boolean> {
    const [follow] = await db.select()
      .from(follows)
      .where(and(
        eq(follows.followerId, followerId),
        eq(follows.followingId, followingId)
      ));
    return !!follow;
  }

  async getFollowers(userId: number, limit = 50): Promise<(Follow & { follower: User })[]> {
    return await db.select({
      id: follows.id,
      followerId: follows.followerId,
      followingId: follows.followingId,
      createdAt: follows.createdAt,
      follower: users,
    })
    .from(follows)
    .innerJoin(users, eq(follows.followerId, users.id))
    .where(eq(follows.followingId, userId))
    .orderBy(desc(follows.createdAt))
    .limit(limit);
  }

  async getFollowing(userId: number, limit = 50): Promise<(Follow & { following: User })[]> {
    return await db.select({
      id: follows.id,
      followerId: follows.followerId,
      followingId: follows.followingId,
      createdAt: follows.createdAt,
      following: users,
    })
    .from(follows)
    .innerJoin(users, eq(follows.followingId, users.id))
    .where(eq(follows.followerId, userId))
    .orderBy(desc(follows.createdAt))
    .limit(limit);
  }

  async createPost(postData: InsertPost): Promise<Post> {
    const [post] = await db
      .insert(posts)
      .values(postData)
      .returning();
    
    return post;
  }

  async getFeedPosts(userId: number, limit = 20): Promise<(Post & { user: User; trip?: Trip; likes: Like[]; likeCount: number; isLiked: boolean })[]> {
    const feedPosts = await db.select({
      id: posts.id,
      userId: posts.userId,
      content: posts.content,
      imageUrl: posts.imageUrl,
      tripId: posts.tripId,
      createdAt: posts.createdAt,
      user: users,
      trip: trips,
    })
    .from(posts)
    .innerJoin(users, eq(posts.userId, users.id))
    .leftJoin(trips, eq(posts.tripId, trips.id))
    .innerJoin(follows, eq(follows.followingId, posts.userId))
    .where(eq(follows.followerId, userId))
    .orderBy(desc(posts.createdAt))
    .limit(limit);

    // Get likes for each post
    const postsWithLikes = await Promise.all(
      feedPosts.map(async (post) => {
        const postLikes = await db.select().from(likes).where(eq(likes.postId, post.id));
        const isLiked = postLikes.some(like => like.userId === userId);
        
        return {
          ...post,
          likes: postLikes,
          likeCount: postLikes.length,
          isLiked,
        };
      })
    );

    return postsWithLikes;
  }

  async likePost(userId: number, postId: number): Promise<Like> {
    const [like] = await db
      .insert(likes)
      .values({ userId, postId })
      .returning();
    
    return like;
  }

  async unlikePost(userId: number, postId: number): Promise<void> {
    await db.delete(likes)
      .where(and(
        eq(likes.userId, userId),
        eq(likes.postId, postId)
      ));
  }
}

export const storage = new DatabaseStorage();

// Carbon calculation function
function calculateCarbonSaved(transportMode: string, distance: number): number {
  const emissionFactors = {
    walking: 0,
    cycling: 0,
    public_transport: 0.05,
    car: 0.21,
    motorcycle: 0.15,
    electric_car: 0.08,
  };

  const carEmission = distance * 0.21; // Average car emission
  const modeEmission = distance * (emissionFactors[transportMode as keyof typeof emissionFactors] || 0);
  
  return Math.max(0, carEmission - modeEmission);
}
