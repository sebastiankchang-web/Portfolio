import { storage } from "./storage";

export async function seedDatabase() {
  try {
    // Check if already seeded by looking for the main user
    const existing = await storage.getUserByUsername("sarah_eco");
    if (existing) {
      return existing;
    }

    // Create sample users
    const users = await Promise.all([
      storage.createUser({
        username: "sarah_eco",
        email: "sarah@example.com",
        displayName: "Sarah Green",
        bio: "Cycling enthusiast and climate advocate",
        profileImageUrl: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face",
        isPublic: true,
      }),
      storage.createUser({
        username: "alex_rider",
        email: "alex@example.com",
        displayName: "Alex Rivera",
        bio: "Public transport champion, saving the planet one ride at a time",
        profileImageUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face",
        isPublic: true,
      }),
      storage.createUser({
        username: "jamie_walker",
        email: "jamie@example.com",
        displayName: "Jamie Walker",
        bio: "Walking everywhere, reducing my carbon footprint step by step",
        profileImageUrl: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face",
        isPublic: true,
      }),
      storage.createUser({
        username: "green_commuter",
        email: "green@example.com",
        displayName: "Green Commuter",
        bio: "Electric car owner transitioning to sustainable transport",
        profileImageUrl: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face",
        isPublic: true,
      }),
    ]);

    console.log("Created users:", users.map(u => u.username));

    // Create sample trips for Sarah (main user)
    const sarahTrips = [
      {
        transportMode: "cycling",
        startLocation: "Home",
        endLocation: "Office",
        distance: 5.2,
        userId: users[0].id,
      },
      {
        transportMode: "walking",
        startLocation: "Office",
        endLocation: "Coffee Shop",
        distance: 0.8,
        userId: users[0].id,
      },
      {
        transportMode: "publicTransport",
        startLocation: "Coffee Shop",
        endLocation: "Gym",
        distance: 3.1,
        userId: users[0].id,
      },
    ];

    const alexTrips = [
      {
        transportMode: "publicTransport",
        startLocation: "Downtown",
        endLocation: "University",
        distance: 8.5,
        userId: users[1].id,
      },
      {
        transportMode: "cycling",
        startLocation: "University",
        endLocation: "Library",
        distance: 2.3,
        userId: users[1].id,
      },
    ];

    const jamieTrips = [
      {
        transportMode: "walking",
        startLocation: "Home",
        endLocation: "Park",
        distance: 1.5,
        userId: users[2].id,
      },
      {
        transportMode: "walking",
        startLocation: "Park",
        endLocation: "Market",
        distance: 2.1,
        userId: users[2].id,
      },
    ];

    const allTrips = [...sarahTrips, ...alexTrips, ...jamieTrips];
    for (const trip of allTrips) {
      await storage.createTrip(trip);
    }

    console.log("Created sample trips");

    await storage.followUser(users[0].id, users[1].id);
    await storage.followUser(users[0].id, users[2].id);
    await storage.followUser(users[1].id, users[0].id);
    await storage.followUser(users[2].id, users[0].id);

    console.log("Database seeded successfully!");
    return users[0];
  } catch (error) {
    console.error("Error seeding database:", error);
    throw error;
  }
}
