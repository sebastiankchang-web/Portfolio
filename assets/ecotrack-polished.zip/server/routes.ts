import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { seedDatabase } from "./seed";
import { insertTripSchema, insertPostSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Initialize database with sample data
  app.all("/api/init", async (req, res) => {
    try {
      const mainUser = await seedDatabase();
      res.json({ message: "Database initialized", mainUser });
    } catch (error) {
      console.error("Init error:", error);
      res.status(500).json({ error: "Failed to initialize database" });
    }
  });

  // Get the current logged-in user (always sarah_eco for this demo)
  app.get("/api/current-user", async (req, res) => {
    try {
      const user = await storage.getUserByUsername("sarah_eco");
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch current user" });
    }
  });

  // Get user stats
  app.get("/api/user/:id/stats", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const stats = await storage.getUserStats(userId);
      
      if (!stats) {
        return res.status(404).json({ error: "User stats not found" });
      }
      
      res.json(stats);
    } catch (error) {
      console.error("Stats error:", error);
      res.status(500).json({ error: "Failed to fetch user stats" });
    }
  });

  // Get user trips
  app.get("/api/user/:id/trips", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      const trips = await storage.getUserTrips(userId, limit);
      
      res.json(trips);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch trips" });
    }
  });

  // Create new trip
  app.post("/api/user/:id/trips", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const tripData = insertTripSchema.parse(req.body);
      
      const trip = await storage.createTrip({ ...tripData, userId });
      
      res.status(201).json(trip);
    } catch (error) {
      res.status(400).json({ error: "Failed to create trip" });
    }
  });

  // Get user achievements
  app.get("/api/user/:id/achievements", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const achievements = await storage.getUserAchievements(userId);
      
      res.json(achievements);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch achievements" });
    }
  });

  // Get dashboard data (combined stats, recent trips, achievements, social feed)
  app.get("/api/user/:id/dashboard", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      
      const [stats, recentTrips, achievements, feedPosts, user] = await Promise.all([
        storage.getUserStats(userId),
        storage.getUserTrips(userId, 5),
        storage.getUserAchievements(userId),
        storage.getFeedPosts(userId, 10),
        storage.getUser(userId),
      ]);

      if (!stats || !user) {
        return res.status(404).json({ error: "User not found" });
      }

      // Calculate today's impact
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const todayTrips = recentTrips.filter(trip => {
        const tripDate = new Date(trip.date);
        tripDate.setHours(0, 0, 0, 0);
        return tripDate.getTime() === today.getTime();
      });
      const todayCarbon = todayTrips.reduce((sum, trip) => sum + trip.carbonSaved, 0);

      // Calculate this week's stats
      const weekAgo = new Date();
      weekAgo.setDate(weekAgo.getDate() - 7);
      const weekTrips = recentTrips.filter(trip => new Date(trip.date) >= weekAgo);
      const weeklyCarbon = weekTrips.reduce((sum, trip) => sum + trip.carbonSaved, 0);
      const weeklyEcoTrips = weekTrips.filter(trip => trip.transportMode !== 'car').length;

      // Get favorite transport mode
      const tripsByMode = recentTrips.reduce((acc, trip) => {
        acc[trip.transportMode] = (acc[trip.transportMode] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);
      
      const favoriteMode = Object.entries(tripsByMode)
        .sort(([,a], [,b]) => b - a)[0]?.[0] || 'cycling';

      // Calculate goal progress
      const monthlyProgress = Math.min(100, (stats.totalCarbonSaved / stats.monthlyGoal) * 100);

      const dashboardData = {
        user,
        stats,
        todayCarbon: Number(todayCarbon.toFixed(1)),
        weeklyStats: {
          ecoTrips: weeklyEcoTrips,
          carbonSaved: Number(weeklyCarbon.toFixed(1)),
          favoriteMode,
          goalProgress: Math.round(monthlyProgress),
        },
        recentTrips: recentTrips.slice(0, 3),
        recentAchievements: achievements.slice(0, 3),
        feedPosts,
      };

      res.json(dashboardData);
    } catch (error) {
      console.error("Dashboard error:", error);
      res.status(500).json({ error: "Failed to fetch dashboard data" });
    }
  });

  // Search users
  app.get("/api/users/search", async (req, res) => {
    try {
      const query = req.query.q as string;
      if (!query) {
        return res.status(400).json({ error: "Query parameter 'q' is required" });
      }
      
      const users = await storage.searchUsers(query);
      res.json(users);
    } catch (error) {
      console.error("Search error:", error);
      res.status(500).json({ error: "Failed to search users" });
    }
  });

  // Follow/unfollow user
  app.post("/api/user/:id/follow", async (req, res) => {
    try {
      const followerId = parseInt(req.params.id);
      const { followingId } = req.body;
      
      const follow = await storage.followUser(followerId, followingId);
      res.json(follow);
    } catch (error) {
      console.error("Follow error:", error);
      res.status(500).json({ error: "Failed to follow user" });
    }
  });

  app.delete("/api/user/:id/follow/:followingId", async (req, res) => {
    try {
      const followerId = parseInt(req.params.id);
      const followingId = parseInt(req.params.followingId);
      
      await storage.unfollowUser(followerId, followingId);
      res.json({ success: true });
    } catch (error) {
      console.error("Unfollow error:", error);
      res.status(500).json({ error: "Failed to unfollow user" });
    }
  });

  // Get following/followers
  app.get("/api/user/:id/following", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const following = await storage.getFollowing(userId);
      res.json(following);
    } catch (error) {
      console.error("Following error:", error);
      res.status(500).json({ error: "Failed to fetch following" });
    }
  });

  app.get("/api/user/:id/followers", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const followers = await storage.getFollowers(userId);
      res.json(followers);
    } catch (error) {
      console.error("Followers error:", error);
      res.status(500).json({ error: "Failed to fetch followers" });
    }
  });

  // Create post
  app.post("/api/posts", async (req, res) => {
    try {
      const postData = insertPostSchema.parse(req.body);
      const post = await storage.createPost(postData);
      res.status(201).json(post);
    } catch (error) {
      console.error("Create post error:", error);
      res.status(400).json({ error: "Failed to create post" });
    }
  });

  // Like/unlike post
  app.post("/api/posts/:id/like", async (req, res) => {
    try {
      const postId = parseInt(req.params.id);
      const { userId } = req.body;
      
      const like = await storage.likePost(userId, postId);
      res.json(like);
    } catch (error) {
      console.error("Like error:", error);
      res.status(500).json({ error: "Failed to like post" });
    }
  });

  app.delete("/api/posts/:id/like/:userId", async (req, res) => {
    try {
      const postId = parseInt(req.params.id);
      const userId = parseInt(req.params.userId);
      
      await storage.unlikePost(userId, postId);
      res.json({ success: true });
    } catch (error) {
      console.error("Unlike error:", error);
      res.status(500).json({ error: "Failed to unlike post" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
