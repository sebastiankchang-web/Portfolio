# EcoTrack - Sustainable Travel Social App

## Overview
EcoTrack is a mobile-first social media application for tracking sustainable travel and carbon emissions reduction. Users can log eco-friendly trips, follow friends, share achievements, and compete in sustainable transportation challenges.

## Recent Changes (June 25, 2025)
✓ Migrated from in-memory storage to PostgreSQL database
✓ Added social media features: following system, user search, activity feed
✓ Modernized UI with clean, minimal design inspired by contemporary social apps
✓ Removed status bar (time/battery) from homepage per user request
✓ Updated navigation with Social tab replacing Stats
✓ Implemented user profiles with bio, profile images, follower/following counts
✓ Added post system for sharing sustainable transportation activities
✓ Integrated Mapbox for location search and route visualization
✓ Replaced bright colors with sleek muted gray/black theme
✓ Added iPhone safe area support and iOS-optimized scrolling
✓ Added realistic routing based on transport modes (walking, cycling, driving)
✓ Multiple route alternatives with duration and distance information
✓ Added airplane as transport option with straight-line routing
✓ Route selection interface showing different path options

## Architecture
- **Frontend**: React + Vite, TailwindCSS, shadcn/ui components
- **Backend**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **State Management**: TanStack Query for server state

## User Preferences
- Modern, social media-like interface
- Clean and sleek design with muted colors
- Mobile-first approach with card-based layouts
- Rounded corners and subtle shadows
- Minimal color scheme using grays and blacks - no bright colors
- Optimized for all iPhone sizes with safe area support

## Key Features
- Trip logging with automatic carbon footprint calculation
- Realistic routing based on transport mode (walking/cycling paths, roads, flight paths)
- Multiple route alternatives with duration and distance comparison
- Social feed showing friends' sustainable transportation activities
- User discovery and following system
- Achievement badges and gamification
- Progress tracking with visual indicators
- Real-time activity sharing
- Interactive maps with location search by name/address

## Database Schema
- users: Basic user info, bio, profile image
- trips: Transportation data with carbon calculations
- posts: Social media posts linked to trips
- follows: User relationship tracking
- likes: Post interaction system
- achievements: Gamification rewards
- user_stats: Aggregated user metrics including social counts